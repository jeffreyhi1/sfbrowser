// author: Ron Valstar
$.sfbrowser.addLang({
	 asciiFileNew:			"New file"
	,asciiFileSave:			"Edit file"
	,axciiFileNameInvalid:	"This is not a valid filename"
	,create:				"Create"
	,contents:				"Contents"
});
<?php
//
// IMPORTANT: This config.php file is just a placeholder, as an example for how you'd handle custom initialisation.
//
echo "\t\t<!-- imageresize config.php -->\n";
?>
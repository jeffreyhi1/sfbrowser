<?php
define("BASE_PATH",		"");
define("BASE_URI",		"");

define("SITE_DATA",		BASE_URI."data/");

define("SITE_THUMB_W",	113);
define("SITE_THUMB_H",	85);

define("PREVIEW_BYTES",	600);

define("SFB_LANG",		"en");
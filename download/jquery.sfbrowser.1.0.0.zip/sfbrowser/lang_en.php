<?php
$aLang = array(
	 "LANG_OK"				=> "Ok"
	,"LANG_CANCEL"			=> "Cancel"
	,"LANG_RESET"			=> "Reset"
	,"LANG_SELECT"			=> "Select"
	,"LANG_CHOOSE"			=> "Choose"
	,"LANG_DELETE"			=> "Delete"
	,"LANG_VIEW"			=> "View"
	,"LANG_DESELECT"		=> "Deselect"
	,"LANG_CLOSE"			=> "Close"
	,"LANG_RELOAD"			=> "Reload"
	,"LANG_UPLOAD"			=> "Upload"
	,"LANG_CHANGED"			=> "changed"

	,"LANG_VIDEO"			=> "video"
	,"LANG_PRESS"			=> "press"

	,"LANG_SHOW"			=> "Show"
	,"LANG_LOAD"			=> "Load"
	,"LANG_SAVE"			=> "Save"
	,"LANG_SAVEAS"			=> "Save as"
	,"LANG_LOADING"			=> "Loading"

	,"LANG_TYPE"			=> "Type"
	,"LANG_NAME"			=> "Name"
	,"LANG_SIZE"			=> "Size"
	,"LANG_FILE"			=> "File"
	,"LANG_FILETYPE"		=> "Filetype"
	,"LANG_FILENAME"		=> "Filename"
	,"LANG_FILESIZE"		=> "Filesize"
	,"LANG_DATE"			=> "Date"
	,"LANG_DIMENSIONS"		=> "Dimensions"
	,"LANG_TITLE"			=> "Title"
	,"LANG_THUMBNAIL"		=> "Thumbnail"

	////////////////////////////////////////////////

	,"LANG_WORK"			=> "Work"
	,"LANG_PRESS"			=> "Press"

	////////////////////////////////////////////
	
	,"LANG_SFB"				=> "SFBrowser"
	
	,"LANG_FILE_DELETED"	=> "File deleted"
	,"LANG_FILE_NOTDELETED"	=> "File could not be deleted"
	,"LANG_FILE_NOTSELECTED"=> "No file selected"
	
	,"LANG_PREVIEW_PART"	=> "Shows the first #1 bytes"
	,"LANG_PREVIEW_TEXT"	=> "- loading text -"

	,"LANG_NEWVIDEOFILE"	=> "New video"
	,"LANG_NEWPRESSFILE"	=> "New press release"
	,"LANG_CLICKADDFILE"	=> "Click to add file"
	,"LANG_GETFIREFOX"		=> "Everything works fine, things just look better in <a href=\"http://www.getfirefox.com/\">Firefox</a>."
	,"LANG_CHANGES"			=> "Changes have been made, don't forget to save."
	,"LANG_NOCHANGES"		=> "There appear to be no changes."
	,"LANG_SAVING"			=> "Saving data..."
	,"LANG_DELETEVIDEO"		=> "Delete video"
	,"LANG_DELETEPRESS"		=> "Delete press release"
	,"LANG_MOVEUP"			=> "Move up"
	,"LANG_MOVEDOWN"		=> "Move down"
	,"LANG_CONFIRM_DELETE"	=> "Delete this item?"
	,"LANG_SAVESUCCES"		=> "Save succesfull"
	,"LANG_UPLOAD_NOTALLOWED"		=> "File is '#1' but has to be one of the following extensions: #2."
);
?>
<?php
$aLang = array(
	 "LANG_OK"				=> "Ok"
	,"LANG_CANCEL"			=> "Annuleren"
	,"LANG_RESET"			=> "Reset"
	,"LANG_SELECT"			=> "Selecteer"
	,"LANG_CHOOSE"			=> "Kies"
	,"LANG_DELETE"			=> "Verwijder"
	,"LANG_VIEW"			=> "Toon"
	,"LANG_DESELECT"		=> "Deselecteer"
	,"LANG_CLOSE"			=> "Sluit"
	,"LANG_RELOAD"			=> "Herladen"
	,"LANG_UPLOAD"			=> "Uploaden"
	,"LANG_CHANGED"			=> "aangepast"

	,"LANG_VIDEO"			=> "video"
	,"LANG_PRESS"			=> "pers"

	,"LANG_SHOW"			=> "Toon"
	,"LANG_LOAD"			=> "Laad"
	,"LANG_SAVE"			=> "Opslaan"
	,"LANG_SAVEAS"			=> "Opslaan als"
	,"LANG_LOADING"			=> "Laden"

	,"LANG_TYPE"			=> "Type"
	,"LANG_NAME"			=> "Naam"
	,"LANG_SIZE"			=> "Grootte"
	,"LANG_FILE"			=> "Bestand"
	,"LANG_FILETYPE"		=> "Bestandstype"
	,"LANG_FILENAME"		=> "Bestandsnaam"
	,"LANG_FILESIZE"		=> "Bestandsgrootte"
	,"LANG_DATE"			=> "Datum"
	,"LANG_DIMENSIONS"		=> "Verhoudingen"
	,"LANG_TITLE"			=> "Titel"
	,"LANG_THUMBNAIL"		=> "Thumbnail"

	////////////////////////////////////////////////

	,"LANG_WORK"			=> "Werk"
	,"LANG_PRESS"			=> "Pers"

	////////////////////////////////////////////
	
	,"LANG_SFB"				=> "SFBrowser"
	
	,"LANG_FILE_DELETED"	=> "Bestand verwijderd"
	,"LANG_FILE_NOTDELETED"	=> "Bestand kon niet worden verwijderd"
	,"LANG_FILE_NOTSELECTED"=> "Er is geen bestand geselecteerd"
	
	,"LANG_PREVIEW_PART"	=> "Toont de eerste #1 bytes"
	,"LANG_PREVIEW_TEXT"	=> "- text laden -"

	,"LANG_NEWVIDEOFILE"	=> "Nieuwe video"
	,"LANG_NEWPRESSFILE"	=> "Nieuw pers bericht"
	,"LANG_CLICKADDFILE"	=> "Klik om een bestand toe te voegen"
	,"LANG_GETFIREFOX"		=> "Alles werkt, maar het ziet er altijd beter uit in <a href=\"http://www.getfirefox.com/\">Firefox</a>."
	,"LANG_CHANGES"			=> "Er zijn aanpassingen gedaan, vergeet niet te saven."
	,"LANG_NOCHANGES"		=> "Er zijn geen veranderingen."
	,"LANG_SAVING"			=> "Bezig op te slaan..."
	,"LANG_DELETEVIDEO"		=> "Verwijder video"
	,"LANG_DELETEPRESS"		=> "Verwijder pers bericht"
	,"LANG_MOVEUP"			=> "Omhoog"
	,"LANG_MOVEDOWN"		=> "Omlaag"
	,"LANG_CONFIRM_DELETE"	=> "Verwijder dit item?"
	,"LANG_SAVESUCCES"		=> "Opslaan gelukt"
	,"LANG_UPLOAD_NOTALLOWED"		=> "Dit bestand is '#1', het moet echter een van de volgende extensies hebben: #2."
);
?>
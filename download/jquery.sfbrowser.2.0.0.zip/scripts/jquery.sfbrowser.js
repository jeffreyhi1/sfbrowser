/*
* jQuery SFBrowser
*
* Version: 2.0.0
*
* Copyright (c) 2008 Ron Valstar http://www.sjeiti.com/
*
* Dual licensed under the MIT and GPL licenses:
*   http://www.opensource.org/licenses/mit-license.php
*   http://www.gnu.org/licenses/gpl.html
*
* description
*   - A file browsing and upload plugin. Returns a list of objects with additional information on the selected files.
*
* features
*   - ajax file upload
*   - localisation
*   - file filtering
*   - file renameing
*   - sortable file table
*	- folder creation
*   - file download
*   - file/folder context menu
*   - image resize
*   - image preview
*   - text/ascii preview
*   - multiple files selection (not in IE for now)
*
* requires
*   - jQuery 1.2+
*   - PHP5
*
* aknowlegdments
*   - ajax file upload scripts from http://www.phpletter.com/Demo/AjaxFileUpload-Demo/
*
* todo:
*	- code: check what timeout code in upload code really does
*	- FF: find way to disable table cell highlighting view (just the border)
*	- IE: multiple selection does not work in IE (must be CTRL)
*	- add: image preview: no-scaling on smaller images
*	- add: multiple selection with shift
*	- add: make text selection in table into multiple file selection
*	- add: try parsing element in chooseFile on contextMenu
*   - new: make preview an option
*   - new: filetype filter
*   - new: folder information such as number of files
*   - IE: fix IE and Safari scrolling (table header moves probably thanks to absolute positioning of parents)
*   - new: add mime instead of extension (for mac)
*	- add: show zip and rar file contents in preview
*	- add: drag and drop files to folders
*   - new: create ascii file
*   - new: edit ascii file
*   - maybe: drag sfbrowser
*   - maybe: copy used functions (copy, unique and indexof) from array.js
*	- maybe: thumbnail view
*
* fixed in this update:
*   - added better explanation, usage and examples in index.php file
*   - sfbrowser now returns a list of objects rather than a list of filenames.
*	  An object contains:
*		 - file(String):		The file including its path
*		 - mime(String):		The filetype
*		 - rsize(int):			The size in bytes
*		 - size(String):		The size formatted to B, kB, MB, GB etc..
*		 - time(int):			The time in seconds from Unix Epoch
*		 - date(String):		The time formatted in "j-n-Y H:i"
*		 - surface(int):		If image, the surface in w*h px
*		 - dimensions(String):	If image, A string: "w x h px"
*   - added 'dirs' to settings
*   - folders browsing
*   - create/delete folders
*   - file/folder rename
*   - file/folder context menu
*	- copied filetype 'deny' to config for security
*   - simple animation
*   - fixed transparent background when scrolling
*   - removed dimensions from release
*   - added packed version to release
*   - private variables instead of global settings
*   - removed path from settings
*	- improved sorting
*	- cleaned lang files
*
*/
;(function($) {
	// private variables
	var oSettings = {};
	var oContents = {};
	var aSort = [];
	var iSort = 0;
	var bHasImgs = false;
	var aPath = [];
	//
	// default settings
	$.sfbrowser = {
		 id: "SFBrowser"
		,version: "2.0.0"
		,defaults: {
			 title:		""								// the title
			,folder:	"data/"							// upload folder
			,dirs:		true							// allow visibility and creation/deletion of subdirectories
			,upload:	true							// allow upload of files
			,deny:		[]								// not allowed file extensions
			,allow:		[]								// allowed file extensions
			,resize:	null							// resize images: array(width,height) or null
			,select:	function(a){trace(a)}			// calback function on choose
			// basic control (normally no need to change)
			,img:		["gif","jpg","jpeg","png"]
			,ascii:		["txt","xml","html","htm","eml","ffcmd","js","as","php","css","java","cpp","pl","log"]
		}
	};
	$.fn.extend({
		sfbrowser: function(_settings) {
			oSettings = $.extend({}, $.sfbrowser.defaults, _settings);
			oSettings.deny = oSettings.deny.concat(sSfbDeny.split(","));
			oContents = {};
			aSort = [];
			bHasImgs = oSettings.allow.length===0||oSettings.img.copy().concat(oSettings.allow).unique().length<(oSettings.allow.length+oSettings.img.length);
			aPath = [];

			// file browser
			var sFBrowser = "<div id=\"sfbrowser\"><div id=\"fbbg\"></div><div id=\"fbwin\"><div class=\"fbcontent\">";
			sFBrowser += "<h3>"+(oSettings.title==""?sLangSfb:oSettings.title)+"</h3>";
			sFBrowser += "<div id=\"loadbar\"><div></div><span>"+sLangLoading+"</span></div>";
			sFBrowser += "<ul id=\"sfbtopmenu\">";
			if (oSettings.dirs) sFBrowser += "	<li><a class=\"textbutton newfolder\" title=\""+sLangNewfolder+"\"><span>"+sLangNewfolder+"</span></a></li>";
			if (oSettings.upload) {
				sFBrowser += "	<li>";
				sFBrowser += "		<form name=\"form\" action=\"\" method=\"POST\" enctype=\"multipart/form-data\">";
				sFBrowser += "			<input id=\"fileToUpload\" type=\"file\" size=\"1\" name=\"fileToUpload\" class=\"input\" />";
				sFBrowser += "		</form>";
				sFBrowser += "		<a class=\"textbutton upload\" title=\""+sLangUpload+"\"><span>"+sLangUpload+"</span></a>";
				sFBrowser += "	</li>";
			}
			sFBrowser += "	<li><a class=\"button cancelfb\" title=\""+sLangCancel+"\">&nbsp;<span>"+sLangCancel+"</span></a></li>";
			sFBrowser += "</ul>";

			sFBrowser += "<div id=\"fbtable\"><table id=\"filesDetails\" cellpadding=\"0\" cellspacing=\"0\"><thead><tr>";
			sFBrowser += "	<th>"+sLangName+"</th>";
			sFBrowser += "	<th>"+sLangType+"</th>";
			sFBrowser += "	<th>"+sLangSize+"</th>";
			sFBrowser += "	<th>"+sLangDate+"</th>";
			if (bHasImgs) sFBrowser += "	<th>"+sLangDimensions+"</th>";
			sFBrowser += "	<th width=\"54\"></th>";
			sFBrowser += "</tr></thead><tbody><tr><td class=\"loading\" colspan=\""+(bHasImgs?6:5)+"\"></td></tr></tbody></table></div>";
			sFBrowser += "<div id=\"fbpreview\"></div>";
			sFBrowser += "<div class=\"button choose\">"+sLangChoose+"</div>";
			sFBrowser += "<div class=\"button cancelfb\">"+sLangCancel+"</div>";
			sFBrowser += "<div id=\"sfbfooter\">SFBrowser "+$.sfbrowser.version+" Copyright (c) 2008 <a href=\"http://www.sjeiti.com/\">Ron Valstar</a></div>";
			sFBrowser += "</div></div></div>";

			$("#sfbrowser").remove();
			mFB = $(sFBrowser).appendTo("body");

			// context menu
			var sFBcontext = "<ul id=\"sfbcontext\">";
			sFBcontext += "<li><a onclick=\"\" class=\"textbutton choose\" title=\""+sLangChoose+"\"><span>"+sLangChoose+"</span></a></li>";
			sFBcontext += "<li><a onclick=\"\" class=\"textbutton rename\" title=\""+sLangRename+"\"><span>"+sLangRename+"</span></a></li>";
			sFBcontext += "<li><a onclick=\"\" class=\"textbutton preview\" title=\""+sLangView+"\"><span>"+sLangView+"</span></a></li>";
			sFBcontext += "<li><a onclick=\"\" class=\"textbutton filedelete\" title=\""+sLangDelete+"\"><span>"+sLangDelete+"</span></a></li>";
			sFBcontext += "</ul>";
			var mFBC = $(sFBcontext).appendTo("#sfbrowser");
			mFBC.find(".choose").click(function(){		chooseFile(); });
			mFBC.find(".rename").click(function(){		renameSelected(); });
			mFBC.find(".preview").click(function(){		$("#sfbrowser tbody>tr.selected:first a.preview").trigger("click"); });
			mFBC.find(".filedelete").click(function(){	$("#sfbrowser tbody>tr.selected:first a.filedelete").trigger("click"); });
			mFBC.find("a").click(function(){			$("#sfbcontext").slideUp("fast"); });

			// functions
			$(window).bind("resize", reposition);
			// top menu
			mFB.find(".cancelfb").click(		closeSFB );
			mFB.find("#fileToUpload").change(	fileUpload);
			mFB.find(".newfolder").click(		addFolder );
			// table
			mFB.find("div.choose").click(		chooseFile);
			mFB.find("thead>tr>th:not(:last)").each(function(i,o){
				$(this).click(function(){sortFbTable(i)});
			}).append("<span>&nbsp;</span>");
			// context menu
			mFB.click(function(){
				$("#sfbcontext").slideUp("fast");
			});

			openDir(oSettings.folder);

			// keys
			// ESC : 27
			// (F1 : xxx : help)				#impossible: F1 browser help
			// F2 : 113 : rename
			// F4 : 115 : edit					#unimplemented
			// (F5 : xxx : copy)				#impossible: F5 reloads
			// (F6 : xxx : move)				#no key in FF
			// (F7 : xxx : create directory)	#no key in FF
			// F8 : 119	: delete				#unimplemented
			// F9 : 120	: properties			#unimplemented
			// (F10 : xxx : quit)				#no key in FF
			// CTRL-A : xxx : select all
			oSettings.keys = [];
			$(window).keydown(function(e){
				oSettings.keys[e.keyCode] = true;
				//trace("key: "+e.keyCode+" ")
				if (e.keyCode==65&&oSettings.keys[17]) {
					$("#sfbrowser tbody>tr").each(function(){$(this).addClass("selected")});
					trace("todo: clear text selection");
				}
			});
			$(window).keyup(function(e){
				//trace("key: "+e.keyCode+" ")
				if (oSettings.keys[113])	renameSelected();
				if (oSettings.keys[27])		closeSFB();
				oSettings.keys[e.keyCode] = false;
			});
			
			reposition();
			
			openSFB();
		}
	});
	// init
	$(function() {
		trace("sfbrowser init");
	});
	// private functions
	//
	// open
	function openSFB() {
		// animation
		mFB.find("#fbbg").css({display:"none"});
		mFB.find("#fbbg").slideDown();
		mFB.find("#fbwin").css({display:"none"});
		mFB.find("#fbwin").slideDown();
	}
	//
	// close
	function closeSFB() {
		$("#sfbrowser #fbbg").fadeOut();
		$("#sfbrowser #fbwin").slideUp("normal",function(){$("#sfbrowser").remove();});
	}
	// reposition
	function reposition() {
		$("#fbwin").css({
			 top: Math.round($(window).height()/2-$("#fbwin").height()/2)
			,left: Math.round($(window).width()/2-$("#fbwin").width()/2)
		});
		$("#sfbcontext").slideUp("fast");
	}
	// sortFbTable
	function sortFbTable(nr) {
		if (nr!==null) {
			iSort = nr;
			aSort[iSort] = aSort[iSort]=="asc"?"desc":"asc";
		} else {
			if (!aSort[iSort]) aSort[iSort] = "asc";
		}

		//$("#sfbrowser tbody>tr").tsort("td:eq("+nr+")[abbr]",{attr:"abbr",order:aSort[nr]});
		$("#sfbrowser tbody>tr.folder").tsort("td:eq(0)[abbr]",{attr:"abbr",order:aSort[iSort]});
		$("#sfbrowser tbody>tr:not(.folder)").tsort("td:eq("+iSort+")[abbr]",{attr:"abbr",order:aSort[iSort]});

		mFB.find("thead>tr>th>span").each(function(i,o){$(this).css({backgroundPosition:(i==iSort?5:-9)+"px "+(aSort[iSort]=="asc"?4:-96)+"px"})});
	}
	// open directory
	function openDir(dir) {
		if (dir) aPath.push(dir);
		else aPath.pop();
		$.ajax({type:"POST", url:"sfbrowser.php", data:"a=chi&folder="+aPath.join(""), dataType:"json", success:fillList});
	}
	// fill list
	function fillList(data,status) {
		if (typeof(data.error)!="undefined") {
			if (data.error!="") {
				trace("chi error: "+data.error);
				alert(data.error);
			} else {
				trace(data.msg);
				$("#sfbrowser tbody").children().remove();
				$("#fbpreview").html("");
				oContents = {};
				aSort = [];
				$.each( data.data, function(i,oFile) {
					// todo: logical operators could be better
					var bDir = (oFile.mime=="folder"||oFile.mime=="folderup");
					if ((oSettings.allow.indexOf(oFile.mime)!=-1||oSettings.allow.length===0)&&oSettings.deny.indexOf(oFile.mime)==-1||bDir) {
						if ((bDir&&oSettings.dirs)||!bDir) listAdd(oFile);
					}
				});
				if (aPath.length>1) listAdd({file:"..",mime:"folderup",rsize:0,size:"-",time:0,date:"",surface:0,dimensions:""});

				$("#sfbrowser thead>tr>th:eq(0)").trigger("click");
			}
		}
	}
	// add item to list
	function listAdd(obj) {;
		oContents[obj.file] = obj;
		var bFolder = obj.mime=="folder";
		var bUFolder = obj.mime=="folderup";
		var sMime = bFolder||bUFolder?sLangFolder:obj.mime;
		var sTr = "<tr id=\""+obj.file+"\" class=\""+(bFolder||bUFolder?"folder":"file")+"\">";
		sTr += "<td abbr=\""+obj.file+"\" title=\""+obj.file+"\" class=\"icon\" style=\"background-image:url(sfbrowser/icons/"+(aIcons.indexOf(obj.mime)!=-1?obj.mime:"default")+".gif);\">"+(obj.file.length>20?obj.file.substr(0,15)+"(...)":obj.file)+"</td>";
		sTr += "<td abbr=\""+obj.mime+"\">"+sMime+"</td>";
		sTr += "<td abbr=\""+obj.rsize+"\">"+obj.size+"</td>";
		sTr += "<td abbr=\""+obj.time+"\">"+obj.date+"</td>";
		sTr += (bHasImgs?("<td"+(obj.surface>0?(" abbr=\""+obj.surface+"\""):"")+">"+obj.dimensions+"</td>"):"");
		sTr += "<td>";
		if (!(bFolder||bUFolder)) sTr += "	<a onclick=\"\" class=\"button preview\" title=\""+sLangView+"\">&nbsp;<span>"+sLangView+"</span></a>";
		if (!bUFolder) sTr += "	<a onclick=\"\" class=\"button filedelete\" title=\""+sLangDelete+"\">&nbsp;<span>"+sLangDelete+"</span></a>";
		sTr += "</td>";
		sTr += "</tr>";
		var mTr = $(sTr).prependTo("#sfbrowser tbody");
		mTr.find("a.filedelete").bind("click", function(el) {
			if (confirm(bFolder?sLangConfirmDeletef:sLangConfirmDelete)) {
				$.ajax({type:"POST", url:"sfbrowser.php", data:"a=ka&folder="+aPath.join("")+"&file="+obj.file, dataType:"json", success:function(data, status){
					if (typeof(data.error)!="undefined") {
						if (data.error!="") {
							trace(data.error);
							alert(data.error);
						} else {
							trace(data.msg);
							$("#fbpreview").html("");
							delete oContents[obj.file];
							mTr.remove();
						}
					}
				}});
			}
			return false; // to prevent renaming
		});
		//mTr.find("td:last").css({textAlign:"right"}); // IE fix
		mTr.bind("mouseover", function() {
			$(this).addClass("over");
		}).bind("mouseout", function() {
			$(this).removeClass("over");
		}).bind("dblclick", function() {
			chooseFile($(this));
		}).click( function(e) {
			clickTr(this,false);
		}).mousedown( function(e) {
			var evt = e;
			$(this).mouseup( function(e) {
				$(this).unbind("mouseup");
				if (evt.button==2) {
					trace("rightclick todo: create context menu: choose, rename, download, delete");
					$("#sfbcontext").slideUp("fast",function(){
						$("#sfbcontext").css({left:e.clientX+1,top:e.clientY+1});
						// check context contents
						$("#sfbcontext").children().css({display:"block"});
						if (bFolder||bUFolder) $("#sfbcontext>li:has(a.preview)").css({display:"none"});
						if (bUFolder) {
							$("#sfbcontext>li:has(a.rename)").css({display:"none"});
							$("#sfbcontext>li:has(a.filedelete)").css({display:"none"});
						}
						$("#sfbcontext").slideDown("fast")
					});;
					clickTr(this,true);
					return false;
				} else {
					return true;
				}
			});
		});
		mTr[0].oncontextmenu = function() {
			return false;
		};

		mTr.find("a.preview").bind("click", function(el) {
			window.open("sfbrowser.php?a=sui&file="+aPath.join("")+obj.file,"_blank");
		});
		return mTr;
	}
	// chooseFile
	function chooseFile(el) {
		var a = 0;
		var aSelected = $("#sfbrowser tbody>tr.selected");
		var aSelect = [];
		// find selected trs and possible parsed element
		aSelected.each(function(){aSelect.push(oContents[$(this).attr("id")])});
		if (el&&el.find) aSelect.push(oContents[$(el).attr("id")]);
		// check if selection contains directory
		for (var i=0;i<aSelect.length;i++) {
			var oFile = aSelect[i];
			if (oFile.mime=="folder") {
				openDir(oFile.file+"/");
				return false;
			} else if (oFile.mime=="folderup") {
				openDir();
				return false;
			}
		}
		// return
		aSelect = aSelect.unique();
		if (aSelect.length==0) {
			alert(sLangFileNotselected);
		} else {
			$.each(aSelect,function(i,oFile){oFile.file = aPath.join("")+oFile.file;});
			oSettings.select(aSelect);
			closeSFB();
		}
	}
	// clickTr
	function clickTr(el,right) {
		var mTr = $(el);
		var oFile = oContents[mTr.attr("id")];
		var bFolder = oFile.mime=="folder";
		var bUFolder = oFile.mime=="folderup";
		var sFile = oFile.file;
		//
		if (!oSettings.keys[16]) trace("todo: shift selection");
		if (!oSettings.keys[17]) $("#sfbrowser tbody>tr").each(function(){if (mTr[0]!=$(this)[0]) $(this).removeClass("selected")});
		//
		// check if something is being renamed
		if (checkRename()[0]!=mTr[0]&&!right&&mTr.hasClass("selected")&&!bUFolder&&!oSettings.keys[17]) {
			renameSelected(mTr);
		} else {
			if (oSettings.keys[17]) mTr.toggleClass("selected");
			else mTr.addClass("selected");
		}
		//
		$("#fbpreview").html("");
		//
		// preview image
		if (oSettings.img.indexOf(oFile.mime)!=-1) {
			$("<img src=\""+aPath.join("")+sFile+"\" />").appendTo("#fbpreview").click(function(){$(this).parent().toggleClass("auto")});
		//
		// preview ascii
		} else if (oSettings.ascii.indexOf(oFile.mime)!=-1) {
			$("#fbpreview").html(sLangPreviewText);
			$.ajax({type:"POST", url:"sfbrowser.php", data:"a=mizu&folder="+aPath.join("")+"&file="+sFile, dataType:"json", success:function(data, status){
					if (typeof(data.error)!="undefined") {
					if (data.error!="") {
						trace("mizu error: "+data.error);
						alert(data.error);
					} else {
						trace(data.msg);
						$("#fbpreview").html("<pre><div>"+sLangPreviewPart.replace("#1",iPreviewBytes)+"</div>\n"+data.data.text.replace(/\>/g,"&gt;").replace(/\</g,"&lt;")+"</pre>");
					}
				}
			}});
		}
	}
	// rename
	function renameSelected(el) {
		var mSelected = el?el:$("#sfbrowser tbody>tr.selected:first");
		var mStd = mSelected.find("td:eq(0)");
		var oFile = oContents[mSelected.attr("id")];
		mStd.html("");
		$("<input type=\"text\" value=\""+oFile.file+"\" />").appendTo(mStd).click(function(){return false;});
	}
	function checkRename() {
		var aRenamed = $("#sfbrowser tbody>tr>td>input");
		if (aRenamed.length>0) {
			var mInput = $(aRenamed[0]);
			var mTd = mInput.parent();
			var mTr = mTd.parent();
			var oFile = oContents[mTr.attr("id")];
			var sFile = oFile.file;
			var sNFile = mInput.val();

			if (sFile==sNFile) {
				mInput.parent().html(sFile.length>20?sFile.substr(0,15)+"(...)":sFile);
			} else {
				$.ajax({type:"POST", url:"sfbrowser.php", data:"a=ho&folder="+aPath.join("")+"&file="+sFile+"&nfile="+sNFile, dataType:"json", success:function(data, status){
					if (typeof(data.error)!="undefined") {
						if (data.error!="") {
							trace(data.error);
							alert(data.error);
						} else {
							trace(data.msg);
							mTd.html(sNFile.length>20?sNFile.substr(0,15)+"(...)":sNFile).attr("title",sNFile).attr("abbr",sNFile);
							oFile.file = sNFile;
						}
					}
				}});
			}
		}
		return mTr?mTr:false;
	}
	// add folder
	function addFolder() {
		trace("addFolder");
		$.ajax({type:"POST", url:"sfbrowser.php", data:"a=tsuchi&folder="+aPath.join(""), dataType:"json", success:function(data, status){
			if (typeof(data.error)!="undefined") {
				if (data.error!="") {
					trace(data.error);
					alert(data.error);
				} else {
					trace(data.msg);
					listAdd(data.data).trigger('click').trigger('click');
					sortFbTable(); // todo: fix scrolltop below because because of
					$("#sfbrowser #fbtable").scrollTop(0);	// IE and Safari
					$("#sfbrowser tbody").scrollTop(0);		// Firefox
				}
			}
		}});
	}
	// loading
	function loading() {
		var iPrgMove = Math.ceil((new Date()).getTime()*.3)%512;
		$("#loadbar>div").css("backgroundPosition", "0px "+iPrgMove+"px");
		$("#loadbar:visible").each(function(){setTimeout(loading,20);});
	}
	// fileUpload
	function fileUpload() {
		trace("fileUpload");
		
		$("#loadbar").ajaxStart(function(){
			$(this).show();
			loading();
		}).ajaxComplete(function(){
			$(this).hide();
		});

		ajaxFileUpload({ // fu
			url:			"sfbrowser.php",
			secureuri:		false,
			fileElementId:	"fileToUpload",
			dataType:		"json",
			success: function (data, status) {
				if (typeof(data.error)!="undefined") {
					if (data.error!="") {
						trace("fu error: "+data.error);
						alert(data.error);
					} else {
						trace(data.msg);
						listAdd(data.data).trigger('click');
						sortFbTable(); // todo: fix scrolltop below because because of
						$("#sfbrowser #fbtable").scrollTop(0);	// IE and Safari
						$("#sfbrowser tbody").scrollTop(0);		// Firefox
					}
					return false; // otherwise upload stays open...
				}
			},
			error: function (data, status, e){
				trace(e);
			}
		});
		return false;
	}
	// is numeric
	function isNum(n) {
		return (parseFloat(n)+"")==n;
	}
	// trace
	function trace(o) {
		if (window.console&&window.console.log) {
			if (typeof(o)=="string")	window.console.log(o);
			else						for (var prop in o) window.console.log(prop+": "+o[prop]);
		}
	};
	////////////////////////////////////////////////////////////////
	//
	// here starts copied functions from http://www.phpletter.com/Demo/AjaxFileUpload-Demo/
	// - changed iframe and form creation to jQuery notation
	//
	function ajaxFileUpload(s) {
		trace("ajaxFileUpload");
        // todo: introduce global settings, allowing the client to modify them for all requests, not only timeout		
        s = jQuery.extend({}, jQuery.ajaxSettings, s);
		//
        var iId = new Date().getTime();
		var sFrameId = "jUploadFrame" + iId;
		var sFormId = "jUploadForm" + iId;
		var sFileId = "jUploadFile" + iId;
		//
		// create form
		var mForm = $("<form  action=\"\" method=\"POST\" name=\"" + sFormId + "\" id=\"" + sFormId + "\" enctype=\"multipart/form-data\"><input name=\"a\" type=\"hidden\" value=\"fu\" /><input name=\"folder\" type=\"hidden\" value=\""+aPath.join("")+"\" /><input name=\"allow\" type=\"hidden\" value=\""+oSettings.allow.join("|")+"\" /><input name=\"deny\" type=\"hidden\" value=\""+oSettings.deny.join("|")+"\" /><input name=\"resize\" type=\"hidden\" value=\""+oSettings.resize+"\" /></form>").appendTo('body').css({position:"absolute",top:"-1000px",left:"-1000px"});
		$("#"+s.fileElementId).before($("#"+s.fileElementId).clone(true).val("")).attr('id', s.fileElementId).appendTo(mForm);
		//
		// create iframe
		var mIframe = $("<iframe id=\""+sFrameId+"\" name=\""+sFrameId+"\"  src=\""+(typeof(s.secureuri)=="string"?s.secureuri:"javascript:false")+"\" />").appendTo("body").css({position:"absolute",top:"-1000px",left:"-1000px"});
		var mIframeIO = mIframe[0];
		//
        // Watch for a new set of requests
        if (s.global&&!jQuery.active++) jQuery.event.trigger("ajaxStart");
        var requestDone = false;
        // Create the request object
        var xml = {};
        if (s.global) jQuery.event.trigger("ajaxSend", [xml, s]);
        // Wait for a response to come back
        var uploadCallback = function(isTimeout) {			
			var mIframeIO = document.getElementById(sFrameId);
            try {				
				if(mIframeIO.contentWindow) {
					xml.responseText = mIframeIO.contentWindow.document.body?mIframeIO.contentWindow.document.body.innerHTML:null;
					xml.responseXML = mIframeIO.contentWindow.document.XMLDocument?mIframeIO.contentWindow.document.XMLDocument:mIframeIO.contentWindow.document;
				} else if(mIframeIO.contentDocument) {
					xml.responseText = mIframeIO.contentDocument.document.body?mIframeIO.contentDocument.document.body.innerHTML:null;
                	xml.responseXML = mIframeIO.contentDocument.document.XMLDocument?mIframeIO.contentDocument.document.XMLDocument:mIframeIO.contentDocument.document;
				}						
            } catch(e) {
				jQuery.handleError(s, xml, null, e);
			}
            if (xml||isTimeout=="timeout") {				
                requestDone = true;
                var status;
                try {
                    status = isTimeout != "timeout" ? "success" : "error";
                    // Make sure that the request was successful or notmodified
                    if (status!="error") {
                        // process the data (runs the xml through httpData regardless of callback)
                        var data = uploadHttpData(xml, s.dataType);    
                        // If a local callback was specified, fire it and pass it the data
                        if (s.success) s.success(data, status);
                        // Fire the global callback
                        if (s.global) jQuery.event.trigger("ajaxSuccess", [xml, s]);
                    } else {
                        jQuery.handleError(s, xml, status);
					}
                } catch(e) {
                    status = "error";
                    jQuery.handleError(s, xml, status, e);
                }

                // The request was completed
                if (s.global) jQuery.event.trigger("ajaxComplete", [xml, s]);

                // Handle the global AJAX counter
                if (s.global && ! --jQuery.active) jQuery.event.trigger("ajaxStop");

                // Process result
                if (s.complete) s.complete(xml, status);

				mIframe.unbind();

                setTimeout(function() {
					try {
						mIframe.remove();
						mForm.remove();
					} catch(e) {
						jQuery.handleError(s, xml, null, e);
					}
				}, 100);

                xml = null;
            }
        };
        // Timeout checker // Check to see if the request is still happening
        if (s.timeout>0) setTimeout(function() { if (!requestDone) uploadCallback("timeout"); }, s.timeout);
        
        try {
			mForm.attr("action", s.url).attr("method", "POST").attr("target", sFrameId).attr("encoding", "multipart/form-data").attr("enctype", "multipart/form-data").submit();
        } catch(e) {			
            jQuery.handleError(s, xml, null, e);
        }
		mIframe.load(uploadCallback);
        return {abort: function () {}};
    }
	function uploadHttpData(r, type) {
        var data = !type;
        data = type=="xml" || data?r.responseXML:r.responseText;
        // If the type is "script", eval it in global context
        if (type=="script")	jQuery.globalEval(data);
        // Get the JavaScript object, if JSON is used.
        if (type=="json")	eval("data = " + data);
        // evaluate scripts within html
        if (type=="html")	jQuery("<div>").html(data).evalScripts();
		//alert($('param', data).each(function(){alert($(this).attr('value'));}));
        return data;
    }
	// set functions
	$.sfb = $.fn.sfbrowser;
})(jQuery);
<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
	<head>
		<title>jquery filebrowser</title>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<style type="text/css">
			
			* {
				font-family: arial, sans, verdana;
			}
			body, html {
				margin: 0px;
				padding: 0px;
			}
			body {
				background-color: #f5f0f0;
			}
			#page {
				width: 600px;
				width: 40em;
				margin: 0 auto;
				padding: 2em;
				background-color: #fff;
			}
			#page h1, #page h2, #page h3 {
				font-family: "Trebuchet MS";
			}
			#page h1 {
				font-size: 1.2em;
			}
			#page h2 {
				color: #800;
				font-size: 1em;
				border-bottom: 1px solid #800;
			}
			#page h3 {
				font-size: .9em;
			}
			#page p {
				font-size: .9em;
				line-height: 1.3em;
			}
			#page a {
				text-decoration: underline;
				color: blue;
				cursor: hand;
				cursor: pointer;
			}

			#page ul#menu li a {
				color: #800;
			}
			#page ul#menu li a:hover {
				color: #d00;
				text-decoration: none;
			}

			#page ul lh {
				font-weight: bold;
			}
			#page ul li {
				font-size: .8em;
			}

			#page table th {
				text-align: left;
				border-bottom: 1px solid #b99;
			}
			#page table th, #page table td {
				font-size: .7em;
				padding-right: 20px;
				vertical-align: top;
			}
			#page table tr.odd {
				background-color: #eee;
			}
			#page .property {
				font-weight: bold;
				color: #666;
			}
		</style>
		<script type="text/javascript" src="scripts/jquery-1.2.6.min.js"></script>
<?php include_once("sfbrowser/init.php"); ?>
		<script type="text/javascript" src="scripts/jquery.sfbrowser.min.js"></script>

		<script type="text/javascript">
			<!--
			function addFiles(aFiles) {
				if ($('#addfiles>ul').length==0) $('#addfiles').html('<ul/>');
				for (var i=0;i<aFiles.length;i++) $("#addfiles>ul").append("<li onclick=\"$(this).remove()\">"+aFiles[i].file+" is "+aFiles[i].size+"</li>");
			}
			function addImages(aFiles) {
				$.each(aFiles,function(i,o){
					$("#addimages").append("<img src=\""+o.file+"\" onclick=\"$(this).remove();\" />");
				});
			}
			$(function(){
				$("h1").text($.sfbrowser.id+" "+$.sfbrowser.version);
				$("#page tr:odd").addClass("odd");
				$("#page tbody>tr").find("td:eq(0)").addClass("property");

				var mMenu = $("<ul id=\"menu\" />").prependTo("h2:first");
				$("h2").each(function(i,o){
					mMenu.append("<li><a href=\"#"+$(this).text()+"\">"+$(this).text()+"</a></li>");
					$(this).attr("id",$(this).text());
				});
			});
			//$(window).load(function() {
			//	$.fn.sfbrowser({folder:sSiteData,select:function(file){addFile(file)}});
			//});
			-->
		</script>
	</head>
	<body>
		<div id="page">
			<h1><span>SFBrowser</span></h1>
			<p>A file browser and uploader for jquery and php5 which returns a list of objects with additional information on the selected files.</p>

			<h2>features</h2>
			<ul>
				<li>ajax file upload</li>
				<li>localisation</li>
				<li>file filtering</li>
				<li>file renameing</li>
				<li>sortable file table</li>
				<li>folder creation</li>
				<li>file download</li>
				<li>file/folder context menu</li>
				<li>image resize</li>
				<li>image preview</li>
				<li>text/ascii preview</li>
				<li>multiple files selection (not in IE for now)</li>
			</ul>

			<h2>installation</h2>
			<ul>
				<li>adjust 'sfbrowser/config.php' to your needs</li>
				<li>include the 'sfbrowser/init.php' in the head of the html</li>
				<li>if not on localhost set the correct chmod of the upload folder and it's contents</li>
			</ul>

			<h2>usage</h2>
			<p>You can call up SFBrowser by '$.fn.sfbrowser();' or the shorter '$.sfb();'</p>
			<p>SFBrowser has a number of properties you can parse:</p>
			<table id="properties" cellpadding="0" cellspacing="0">
				<thead><tr><th>property</th><th>type</th><th>description</th><th>default</th></tr></thead>
				<tbody>
					<tr><td>title</td>	<td>string</td>		<td>The title of the SFBrowser window.</td><td>"SFBrowser"</td></tr>
					<tr><td>select</td>	<td>function</td>	<td>Calback function on choose</td><td>function(a){trace(a)}</td></tr>
					<tr><td>folder</td>	<td>string</td>		<td>The upload folder.</td><td>"data/"</td></tr>
					<tr><td>dirs</td>	<td>boolean</td>	<td>Allow visibility and creation/deletion of subdirectories.</td><td>true</td></tr>
					<tr><td>upload</td>	<td>boolean</td>	<td>Allow upload of files.</td><td>true</td></tr>
					<tr><td>deny</td>	<td>array</td>		<td>Denied file extensions</td><td>["php", "php3", "phtml"]</td></tr>
					<tr><td>allow</td>	<td>array</td>		<td>Allowed file extensions</td><td>[]</td></tr>
					<tr><td>resize</td>	<td>array</td>		<td>Resize images: array(width,height) or null</td><td>null</td></tr>
					<tr><td>img</td>	<td>array</td>		<td>Image file extensions for preview.</td><td>["gif", "jpg", "jpeg", "png"]</td></tr>
					<tr><td>ascii</td>	<td>array</td>		<td>Text file extensions for preview.</td><td>["txt", "xml", "html", "htm", "eml", "ffcmd", "js", "as", "php", "css", "java", "cpp", "pl", "log"]</td></tr>
				</tbody>
			</table>

			<h3>select</h3>
			<p>The <span class="property">select</span> property is something you will want to set if you want SFBrowser to be usefull. It eats a function with one argument: an array containing objects for the selected files. Each object has the following properties (where applicable):</p>
			<table id="returnobjects" cellpadding="0" cellspacing="0">
				<thead><tr><th>property</th><th>type</th><th>description</th></tr></thead>
				<tbody>
					<tr><td>file</td>		<td>string</td>		<td>The file including its path</td></tr>
					<tr><td>mime</td>		<td>string</td>		<td>The filetype</td></tr>
					<tr><td>rsize</td>		<td>integer</td>	<td>The size in bytes</td></tr>
					<tr><td>size</td>		<td>string</td>		<td>The size formatted to B, kB, MB, GB etc..</td></tr>
					<tr><td>time</td>		<td>integer</td>	<td>The time in seconds from Unix Epoch</td></tr>
					<tr><td>date</td>		<td>string</td>		<td>The time formatted in "j-n-Y H:i"</td></tr>
					<tr><td>surface</td>	<td>integer</td>	<td>If image, the surface in w*h px</td></tr>
					<tr><td>dimensions</td>	<td>string</td>		<td>If image, a string: "w x h px"</td></tr>
				</tbody>
			</table>

			<h3>folder</h3>
			<p>For security reasons you will have to set the <span class="property">folder</span> property. You can leave it the default 'data/' but you cannot parse values like '/', '', './' or '../'.<br/>
			The <span class="property">folder</span> value you provide will be used as the base-path. From there you can go deeper into folders, but you can never go higher than the parsed <span class="property">folder</span> value.</p>

			<h3>allow and deny</h3>
			<p>These properties are arrays containing file extensions that are, or are not shown in SFBrowser. This also applies to the file types that you upload.<br/>
			For security reasons the main deny list is located at 'sfbrowser/config.php' by the name of SFB_DENY (a comma separated list of extenions). Additional file types can be denied through javascript with the <span class="property">deny</span> property.<br/>
			If <span class="property">allow</span> is left empty (which is the default) all file types are allowed except those listed in <span class="property">deny</span>.<br/>
			Denying is stronger than allowing so an extension in both arrays will always be denied. The SFB_DENY constant in 'sfbrowser/config.php' always has priority over the <span class="property">deny</span> property.</p>

			<h2>config</h2>

			<h3>languages</h3>
			<p>You can easily make SFBrowser into another language. Simply copy one of the existing language php files (sfbrowser/en.php) and name them the <a href="http://en.wikipedia.org/wiki/ISO_3166-1_alpha-2#Officially_assigned_code_elements">ISO_3166 code</a> of that language (but in lowercase). Then edit the SFB_LANG constant in 'sfbrowser/config.php' to that ISO code.<br/>
			If you are on a localhost PHP will automaticly write or update the language js files when SFBrowser is run in that language.<br/>
			If you are not on a localhost it is best to upload an (empty) js file with the correct name and CHMOD them writable.<br/>
			Should you make any language file other than the ones already present, I'd be happy to include them in a later release. Please send them to: sfbrowser at sjeiti dot com.</p>

			<h3>ASCII preview</h3>
			<p>Also ascii files can be previewed up to a certain amout of bytes. This amount can be altered by setting the PREVIEW_BYTES constant in 'sfbrowser/config.php'.</p>

			<h2>examples</h2>

			<h3>A simple one</h3>
			<p>The selected files are added to a list and their sizes are shown. Select multiple files by pressing CTRL and selecting. Start <a onclick="$.sfb({folder:'data/',select:addFiles});">adding files.</a></p>
			<div id="addfiles"></div>
			
			<h3>Allowing only images</h3>
			<p>The <span class="property">allow</span> property is set to accept only images. The selected images are added to a div. Note also the title of the SFBrowser is now changed to: <a onclick="$.sfb({folder:'data/ImageFolder/',title:'Add some images',allow:['jpeg','png','gif','jpg'],select:addImages});">Add some images</a>.</p>
			<div id="addimages"></div>

			<h2>a note of caution</h2>
			<p>My initial intentions for this jQuery plugin were for use in a CMS, and those are normally password protected. I can imagine use of this plugin in applications that are not password protected. Of course I've tried to make these scripts as safe as possible but I'm not an expert in PHP and servers. So doublecheck the PHP yourself if you intend to use it on an unprotected part of your site (and use at your own risk of course).<br/>
			Should you find any holes or anything that can be improved please mail me at: sfbrowser at sjeiti dot com.</p>
		</div>
	</body>
</html>
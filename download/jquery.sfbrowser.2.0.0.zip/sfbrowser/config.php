<?php
define("BASE_PATH",			"");
define("BASE_URI",			"");

define("PREVIEW_BYTES",		600);

define("SFB_ERROR_RETURN",	"<html><head><meta http-equiv=\"Refresh\" content=\"0;URL=http:/\" /></head></html>");

define("SFB_LANG",			"en");

define("SFB_DENY",			"php,php3,phtml");
<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
	<head>
		<title>jquery filebrowser</title>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<style type="text/css">
			* {
				font-family: arial, sans, verdana;
			}
			#page {
				width: 600px;
				margin: 0 auto;
			}
			#page ul lh {
				font-weight: bold;
			}
			#page>a {
				text-decoration: underline;
				color: blue;
				cursor: hand;
				cursor: pointer;
			}
		</style>
		<script type="text/javascript" src="scripts/jquery-1.2.6.min.js"></script>
<?php include_once("sfbrowser/init.php"); ?>
		<script type="text/javascript" src="scripts/jquery.sfbrowser.min.js"></script>
		<script type="text/javascript" src="scripts/jquery.dimensions.pack.js"></script>

		<script type="text/javascript">
			<!--
			function addFile(files) {
				for (var i=0;i<files.length;i++) $("#files").append("<li>"+files[i]+"</li>");
			}
			//$(window).load(function() {
			//	$.fn.sfbrowser({folder:sSiteData,select:function(file){addFile(file)}});
			//});
			-->
		</script>
	</head>
	<body>
		<div id="page">
			<h1><span>SFBrowser</span></h1>
			<p>A file browser and uploader for jquery and php5.</p>
			<h2>installation</h2>
			<ul>
				<li>adjust 'sfbrowser/config.php' to your needs</li>
				<li>include the 'sfbrowser/init.php' in the head of the html</li>
				<li>if not on localhost set the correct chmod of the upload folder and it's contents</li>
			</ul>

			<h2>demo</h2>
			<p>SFBrowser can upload and list to any folder that is not the (relative) root. In this case all files are in the same folder, the first two however are filtered on file-type.</p>
			<a onclick="$.fn.sfbrowser({folder:sSiteData,allow:['jpeg','png','gif','jpg'],select:function(file){addFile(file)},title:'Choose an image'});">Add image</a><br/>
			<p>Adding the 'resize' option allow you to resize uploaded images.</p>
			<a onclick="$.fn.sfbrowser({folder:sSiteData,allow:['jpeg','jpg'],resize:[100,80],select:function(file){addFile(file)},title:'Choose an image'});">Add thumbail</a><br/>
			<p>Also ascii files can be previewed up to a certain amout of bytes.</p>
			<a onclick="$.fn.sfbrowser({folder:sSiteData,select:function(file){addFile(file)}});">Add file</a>
			<p>By default you cannot view or upload php files, this can be overridden. Just adding them to 'allow' will not work, you have to specifically remove them from 'prevent'.</p>
			<a onclick="$.fn.sfbrowser({folder:sSiteData,allow:['php'],prevent:[],select:function(file){addFile(file)}});">Add php</a>
			
			<h3>list of selected files</h3>
			<ul id="files"></ul>

			<!--div style="width:10000px;height:10000px;"></div-->
		</div>
	</body>
</html>
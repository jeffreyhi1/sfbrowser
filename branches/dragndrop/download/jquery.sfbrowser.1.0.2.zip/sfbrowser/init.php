<?php // this file needs to be called in the header of your document because it adds css and js

include_once("config.php");
include_once("functions.php");

// create language constants
include_once("lang_".SFB_LANG.".php");
foreach ($aLang as $c=>$s) @define($c,$s);

// check language files (lang_x.js needs to be writable)
$sPhpLang = "sfbrowser/lang_".SFB_LANG.".php";
$sJsLang = "sfbrowser/lang_".SFB_LANG.".js";
if (!file_exists($sJsLang)||filemtime($sJsLang)<filemtime($sPhpLang)) {
	$oJsHdl = fopen($sJsLang, 'w') or die("can't open file");
	$sJs = "// You don't need to edit this file. It is generated from the similarly named php file. Do make sure this file can be written to.\n";
	foreach ($aLang as $c=>$s) $sJs .= "var s".camelCase($c)."=\"".str_replace("\"","\\\"",$s)."\";";
	fwrite($oJsHdl, $sJs);
	fclose($oJsHdl);
}

// add javascript to header
constantsToJs(array ("BASE_URI","SITE_THUMB_W","SITE_THUMB_H","SITE_DATA","PREVIEW_BYTES"));
echo "\t\t<link rel=\"stylesheet\" type=\"text/css\" media=\"screen\" href=\"sfbrowser/css/sfbrowser.css\" />\n";
echo "\t\t<script type=\"text/javascript\" src=\"sfbrowser/lang_".SFB_LANG.".js\"></script>\n";
echo "\t\t<script type=\"text/javascript\" src=\"sfbrowser/array.js\"></script>\n";
echo "\t\t<script type=\"text/javascript\" src=\"sfbrowser/jquery.tinysort.min.js\"></script>\n";

// check existing icons
$aIcons = array();
if ($handle = opendir("sfbrowser/icons/")) while (false !== ($file = readdir($handle))) if (filetype("sfbrowser/icons/".$file)=="file") $aIcons[] = array_shift(explode(".",$file));
echo "\t\t<script type=\"text/javascript\">var aIcons = ['".implode("','",$aIcons)."'];</script>\n";
?>
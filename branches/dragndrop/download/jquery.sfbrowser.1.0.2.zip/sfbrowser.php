<?php
/*
* jQuery SFBrowser 1.0.2
* Copyright (c) 2008 Ron Valstar http://www.sjeiti.com/
* Dual licensed under the MIT and GPL licenses:
*   http://www.opensource.org/licenses/mit-license.php
*   http://www.gnu.org/licenses/gpl.html
*/
if (!(isset($_POST["a"])||isset($_GET["a"]))) exit("ku");
include_once("sfbrowser/config.php");
include_once("sfbrowser/functions.php");
include_once("sfbrowser/lang_".SFB_LANG.".php");
foreach ($aLang as $c=>$s) @define($c,$s);
//
$sData = "";
$sErr = "";
$sMsg = "";//"pcnt:".count($_POST).",";
//
// chi / tsuchi: Earth
// sui / mizu: Water
// ho / ka / hi: Fire
// fu / kaze: Wind
// ku
//
// _GET : file
// _POST : a folder file allow resize
// _FILES : fileToUpload["name"]
//
// security file checking
$sSFile = "";
if (isset($_POST["file"])) $sSFile = $_POST["file"];
else if (isset($_GET["file"])) $sSFile = $_GET["file"];
else if (isset($_FILES["fileToUpload"])) $sSFile = $_FILES["fileToUpload"]["name"];
if ($sSFile!="") {
	if (isset($_POST["folder"])) $sSFile = $_POST["folder"].$sSFile;
	if (strstr($sSFile,"sfbrowser")!==false||!preg_match('/[^:\*\?<>\|(\.\/)]+\/[^:\*\?<>\|(\.\/)]+\.\w{2,6}/',$sSFile)) exit(SFB_ERROR_RETURN);
}
//
//
function fileInfo($sFile) {
	$aRtr = array();
	$aRtr["type"] = filetype($sFile);
	if ($aRtr["type"]=="file") {
		$aRtr["time"] = filemtime($sFile);
		$aRtr["date"] = date("j-n-Y H:i",$aRtr["time"]);
		$aRtr["size"] = filesize($sFile);
		$aRtr["mime"] = array_pop(split("\.",$sFile));//mime_content_type($sFile);
		//
		$aRtr["dim"] = "";
		$aRtr["surface"] = 0;
		$aImgNfo = ($aRtr["mime"]=="jpeg"||$aRtr["mime"]=="jpg"||$aRtr["mime"]=="gif") ? getimagesize($sFile) : "";
		if (is_array($aImgNfo)) {
			list($width, $height, $type, $attr) = $aImgNfo;
			$aRtr["dim"] = $width." x ".$height." px";
			$aRtr["surface"] = $width*$height;
		}
		$sNfo  = "file:\"".		array_pop(split("\/",$sFile))."\",";
		$sNfo .= "mime:\"".		$aRtr["mime"]."\",";
		$sNfo .= "rsize:".		$aRtr["size"].",";
		$sNfo .= "size:\"".		format_size($aRtr["size"])."\",";
		$sNfo .= "time:".		$aRtr["time"].",";
		$sNfo .= "date:\"".		$aRtr["date"]."\",";
		$sNfo .= "surface:".	$aRtr["surface"].",";
		$sNfo .= "dimensions:\"".$aRtr["dim"]."\"";

		$aRtr["stringdata"] = $sNfo;
	}
	return $aRtr;
}
//
$sAction = isset($_POST["a"])?$_POST["a"]:$_GET["a"];
switch ($sAction) {

	case "chi": // retreive file list
		if (count($_POST)!=2||!isset($_POST["folder"])) exit("ku chi");
		$sImg = "";
		$sDir = isset($_POST["folder"])?$_POST["folder"]:"data/";
		$i = 0;
		if ($handle = opendir($sDir)) while (false !== ($file = readdir($handle))) {
			$oFNfo = fileInfo($sDir.$file);
			if (isset($oFNfo["stringdata"])) $sImg .= numToAZ($i).":{".$oFNfo["stringdata"]."},";
			$i++;
		}
		$sMsg .= "file listing";
		$sData = substr($sImg,0,strlen($sImg)-1);
	break;

	case "fu": // file upload
		//if (count($_POST)!=4||!isset($_POST["folder"])||!isset($_POST["resize"])||!isset($_POST["allow"])) exit("ku fu");
		$sElName = "fileToUpload";
		if (!empty($_FILES[$sElName]["error"])) {
			switch($_FILES[$sElName]["error"]) {
				case "1": $sErr = "The uploaded file exceeds the upload_max_filesize directive in php.ini"; break;
				case "2": $sErr = "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form"; break;
				case "3": $sErr = "The uploaded file was only partially uploaded"; break;
				case "4": $sErr = "No file was uploaded."; break;
				case "6": $sErr = "Missing a temporary folder"; break;
				case "7": $sErr = "Failed to write file to disk"; break;
				case "8": $sErr = "File upload stopped by extension"; break;
				default: $sErr = "No error code avaiable";
			}
		} else if (empty($_FILES["fileToUpload"]["tmp_name"])||$_FILES["fileToUpload"]["tmp_name"]=="none") {
			$sErr = "No file was uploaded..";
		} else {
			$sFolder = $_POST["folder"]; // compare folder and base_uri
			//$sPath = BASE_PATH.str_replace("/","\\",array_pop(explode(BASE_URI,$sFolder)));
			$sPath = BASE_PATH.(BASE_URI==""?$sFolder:array_pop(explode(BASE_URI,$sFolder)));

			$sPrevent = $_POST["prevent"];
			$sAllow = $_POST["allow"];
			$sResize = $_POST["resize"];

			$oFile = $_FILES["fileToUpload"];
			$sFile = $oFile["name"];
			$sMime = array_pop(split("\.",$sFile));//mime_content_type($sDir.$file); //$oFile["type"]; //
			//
			$iRpt = 1;
			$sFileTo = $sPath.$oFile["name"];
			while (file_exists($sFileTo)) {
				$aFile = explode(".",$oFile["name"]);
				$aFile[0] .= "_".($iRpt++);
				$sFile = implode(".",$aFile);
				$sFileTo = $sPath.$sFile;
			}
			move_uploaded_file( $oFile["tmp_name"], $sFileTo );
			if ($iRpt==1) $sMsg .= LANG_FILE_UPLOADED;
			else $sMsg .= LANG_FILE_EXISTSRENAMED;
			//
			// check if file is allowed in this session
			$bAllow = $sAllow=="";
			$sFileExt = array_pop(explode(".",$sFile));
			foreach (explode("|",$sAllow) as $sAllowExt) {
				if ($sAllowExt==$sFileExt) {
					$bAllow = true;
					break;
				}
			}
			foreach (explode("|",$sPrevent) as $sPreventExt) {
				if ($sPreventExt==$sFileExt) {
					$bAllow = false;
					break;
				}
			}
			if (!$bAllow) {
				$sErr = str_replace(array("#1","#2","#3"),array($sFileExt,str_replace("|",", ",$sAllow),str_replace("|",", ",$sPrevent)),LANG_UPLOAD_NOTALLOWED);
				@unlink($sFileTo);
			} else {
				if ($sResize!="null"&&($sMime=="jpeg"||$sMime=="jpg")) {
					$aResize = explode(",",$sResize);
					$iToW = $aResize[0];
					$iToH = $aResize[1];
					list($iW,$iH) = getimagesize($sFileTo);
					$oImgN = imagecreatetruecolor($iToW,$iToH);
					$oImg = imagecreatefromjpeg($sFileTo);
					imagecopyresampled($oImgN,$oImg, 0,0, 0,0, $iToW,$iToH, $iW,$iH );
					imagejpeg($oImgN, $sFileTo);
				}
				$oFNfo = fileInfo($sFileTo);
				$sData = $oFNfo["stringdata"];
			}
			@unlink($sFileTo);
		}
	break;

	case "ka": // file delete
		if (count($_POST)!=3||!isset($_POST["folder"])||!isset($_POST["file"])) exit("ku ka");
		if (@unlink($sSFile)) $sMsg .= LANG_FILE_DELETED;
		else $sErr .= LANG_FILE_NOTDELETED;
	break;

	case "sui":// file force download
		if (count($_GET)!=2||!isset($_GET["file"])) exit("ku sui");
		ob_start();
		$sType = "application/octet-stream";
		header("Cache-Control: public, must-revalidate");
		header("Pragma: hack");
		header("Content-Type: " . $sSFile);
		header("Content-Length: " .(string)(filesize($sSFile)) );
		header('Content-Disposition: attachment; filename="'.array_pop(explode("/",$sSFile)).'"');
		header("Content-Transfer-Encoding: binary\n");
		ob_end_clean();
		readfile($sSFile);
	break;

	case "mizu":// read txt file contents
		$oHnd = fopen($sSFile, "r");
		$sCnt = preg_replace(array("/\n/","/\r/"),array("\\n","\\r"),addslashes(fread($oHnd, 600)));
		fclose($oHnd);
		$sData = "text:\"".$sCnt."\"";
		$sMsg .= "Contents retreived.";
	break;
}
if ($sAction!="sui") echo "{error: \"".$sErr."\", msg: \"".$sMsg."\", data: {".$sData."}}";
?>
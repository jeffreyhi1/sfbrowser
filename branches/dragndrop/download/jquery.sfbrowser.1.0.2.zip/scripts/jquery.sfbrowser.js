/*
* jQuery SFBrowser
*
* Version: 1.0.2
*
* Copyright (c) 2008 Ron Valstar http://www.sjeiti.com/
*
* Dual licensed under the MIT and GPL licenses:
*   http://www.opensource.org/licenses/mit-license.php
*   http://www.gnu.org/licenses/gpl.html
*
* description
*   - a file browsing and upload plugin
*
* features
*   - ajax file upload
*   - localisation
*   - file filtering
*   - sortable file table
*   - file download
*   - image resize
*   - image preview
*   - text/ascii preview
*   - multiple files selection (not in IE for now)
*
* requires
*   - jQuery 1.2+
*   - PHP5
*   - jquery.dimensions (as of jQuery SVN Revision 5345 merged into the jQuery core. )
*
* aknowlegdments
*   - ajax file upload scripts from http://www.phpletter.com/Demo/AjaxFileUpload-Demo/
*
* todo:
*   - find and fix 'Permission denied to get property XULElement.accessibleType' (seems to come from dimensions)
*	- check what timeout code in upload code really does
*   - maybe copy used functions (copy, unique and indexof) from array.js
*	- find solution for accessing settings in private functions (settings now 'global')
*	- find way to disable table cell highlighting view (just the border)
*	- multiple selection does not work in IE (must be CTRL)
*	- multiple selection with shift
*	- while at the text selection: make text selection in table into multiple file selection
*   - make preview an option
*   - create/delete folders
*   - file rename
*   - add filetype filter
*   - add folder information such as number of files
*   - fix IE and Safari scrolling (table header moves probably thanks to absolute positioning of parents)
*   - add mime instead of extension (for mac)
*   - fix transparent background when scrolling
*   - drag sfbrowser
*	- thumbnail view (maybe)
*	- show zip and rar file contents in preview
*	- pack it
*
* fixed in this update:
*   - fixed stupid prevent php bug
*
*/
;(function($) {
	// default settings
	$.sfbrowser = {
		id: "SFBrowser",
		version: "1.0.2",
		defaults: {
			 title:		""								// the title
			,folder:	"data/"							// upload folder
			,path:		""								// the default upload path
			,prevent:	new Array("php","php3","phtml")	// not allowed file extensions
			,allow:		new Array()						// allowed file extensions
			,resize:	null							// resize images: array(width,height) or null
			,select:	function(a){trace(a)}			// calback function on choose
			// basic control (normally no need to change)
			,img:		new Array("gif","jpg","jpeg","png")
			,ascii:		new Array("txt","xml","html","htm","eml","ffcmd","js","as","php","css","java","cpp","pl","log")
		}
	};
	$.fn.extend({
		sfbrowser: function(_settings) {
			var oSettings = $.extend({}, $.sfbrowser.defaults, _settings);
			$.sfbrowser.settings = oSettings;
			oSettings.hasimgs = oSettings.allow.length===0||oSettings.img.copy().concat(oSettings.allow).unique().length<(oSettings.allow.length+oSettings.img.length);
			oSettings.fbsort = [];


			var sFBrowser = "<div id=\"sfbrowser\"><div id=\"fbbg\"></div><div id=\"fbwin\"><div class=\"fbcontent\">";
			sFBrowser += "<h3>"+(oSettings.title==""?sLangSfb:oSettings.title)+"</h3>";
			sFBrowser += "<div id=\"loadbar\"><div></div><span>"+sLangLoading+"</span></div>";
			sFBrowser += "<form name=\"form\" action=\"\" method=\"POST\" enctype=\"multipart/form-data\">";
			sFBrowser += "	<input id=\"fileToUpload\" type=\"file\" size=\"1\" name=\"fileToUpload\" class=\"input\">";
			sFBrowser += "</form>";
			sFBrowser += "<a class=\"button cancelfb\" title=\""+sLangCancel+"\"><span>"+sLangCancel+"</span></a>";
			sFBrowser += "<a class=\"textbutton upload\" title=\""+sLangUpload+"\"><span>"+sLangUpload+"</span></a>";
			sFBrowser += "<div id=\"fbtable\"><table id=\"filesDetails\" cellpadding=\"0\" cellspacing=\"0\"><thead><tr>";
			sFBrowser += "	<th>"+sLangName+"</th>";
			sFBrowser += "	<th>"+sLangType+"</th>";
			sFBrowser += "	<th>"+sLangSize+"</th>";
			sFBrowser += "	<th>"+sLangDate+"</th>";
			sFBrowser += (oSettings.hasimgs?"	<th>"+sLangDimensions+"</th>":"");
			sFBrowser += "	<th width=\"54\"></th>";
			sFBrowser += "</tr></thead><tbody><tr><td class=\"loading\" colspan=\""+($.sfbrowser.settings.hasimgs?6:5)+"\"></td></tr></tbody></table></div>";
			sFBrowser += "<div id=\"fbpreview\"></div>";
			sFBrowser += "<div class=\"button choose\">"+sLangChoose+"</div>";
			sFBrowser += "<div class=\"button cancelfb\">"+sLangCancel+"</div>";
			sFBrowser += "<div id=\"sfbfooter\">SFBrowser "+$.sfbrowser.version+" Copyright (c) 2008 <a href=\"http://www.sjeiti.com/\">Ron Valstar</a></div>";
			sFBrowser += "</div></div></div>";

			$("#sfbrowser").remove();
			mFB = $(sFBrowser).appendTo("body");

			// functions
			$(window).bind("resize", reposition);
			mFB.find(".cancelfb").bind("click", function(){$("#sfbrowser").remove()});
			mFB.find("#fileToUpload").bind("change", fileUpload);
			mFB.find("div.choose").bind("click", chooseFile);
			mFB.find("thead>tr>th").each(function(i,o){
				$(this).click(function(){sortFbTable(i)});
			}).append("<span>&nbsp;</span>");

			$.ajax({type:"POST", url:"sfbrowser.php", data:"a=chi&folder="+oSettings.folder, dataType:"json", success:fillList});

			// keys
			oSettings.keys = [];
			$(window).keydown(function(e){
				oSettings.keys[e.keyCode] = true;
				//trace("key: "+e.keyCode+" ")
				if (e.keyCode==65&&oSettings.keys[17]) {
					$("#sfbrowser tbody>tr").each(function(){$(this).addClass("selected")});
					trace("todo: clear text selection");
				}
			});
			$(window).keyup(function(e){
				if (oSettings.keys[113]) trace("todo: rename");
				oSettings.keys[e.keyCode] = false;
			});
			
			reposition();
		}
	});
	// init
	$(function() {
		trace("sfbrowser init");
	});
	// private functions
	//
	// chooseFile
	function chooseFile(el) {
		var a = 0;
		var aSelected = $("#sfbrowser tbody>tr.selected");
		var aSelect = [];
		aSelected.each(function(){aSelect.push($(this).find("td:eq(0)").attr("title"))});
		if (el.find) aSelect.push(el.find("td:eq(0)").attr("title"));
		aSelect.unique();
		if (aSelect.length==0) {
			alert(sLangFileNotselected);
		} else {
			$.sfbrowser.settings.select(aSelect);
			$("#sfbrowser").remove();
		}
	}
	// private functions
	function reposition() {
		$("#fbwin").css({
			 top: Math.round($(window).height()/2-$("#fbwin").height()/2)
			,left: Math.round($(window).width()/2-$("#fbwin").width()/2)
		});
	}
	// sortFbTable
	function sortFbTable(nr) {
		var oSet = $.sfbrowser.settings;
		oSet.fbsort[nr] = oSet.fbsort[nr]=="asc"?"desc":"asc";
		$("#sfbrowser tbody>tr").tsort("td:eq("+nr+")[abbr]",{attr:"abbr",order:oSet.fbsort[nr]});
		mFB.find("thead>tr>th>span").each(function(i,o){$(this).css({backgroundPosition:(i==nr?5:-9)+"px "+(oSet.fbsort[nr]=="asc"?4:-96)+"px"})});
	}
	// fill list
	function fillList(data,status) {
		var oSet = $.sfbrowser.settings;
		if (typeof(data.error)!="undefined") {
			if (data.error!="") {
				trace("ka error: "+data.error);
				alert(data.error);
			} else {
				trace(data.msg);
				$("#sfbrowser tbody").children().remove();
				$.each( data.data, function(i,oFile) {
					if ((oSet.allow.indexOf(oFile.mime)!=-1||oSet.allow.length===0)&&oSet.prevent.indexOf(oFile.mime)==-1) listAdd(oFile);
				});
			}
		}
	}
	// add item to list
	function listAdd(obj) {
		var oSet = $.sfbrowser.settings;
		var sTr = "<tr>";
		sTr += "<td abbr=\""+obj.file+"\" title=\""+obj.file+"\" class=\"icon\" style=\"background-image:url(sfbrowser/icons/"+(aIcons.indexOf(obj.mime)!=-1?obj.mime:"default")+".gif);\">"+(obj.file.length>20?obj.file.substr(0,15)+"(...)":obj.file)+"</td>";
		sTr += "<td abbr=\""+obj.mime+"\">"+obj.mime+"</td>";
		sTr += "<td abbr=\""+obj.rsize+"\">"+obj.size+"</td>";
		sTr += "<td abbr=\""+obj.time+"\">"+obj.date+"</td>";
		sTr += (oSet.hasimgs?("<td"+(obj.surface>0?(" abbr=\""+obj.surface+"\""):"")+">"+obj.dimensions+"</td>"):"");
		sTr += "<td>";
		sTr += "	<a onclick=\"\" class=\"button preview\" title=\""+sLangView+"\"><span>"+sLangView+"</span></a>";
		sTr += "	<a onclick=\"\" class=\"button filedelete\" title=\""+sLangDelete+"\"><span>"+sLangDelete+"</span></a>";
		sTr += "</td>";
		sTr += "</tr>";
		var mTr = $(sTr).prependTo("#sfbrowser tbody");
		mTr.find("a.filedelete").bind("click", function(el) {
			if (confirm(sLangConfirmDelete)) {
				$.ajax({type:"POST", url:"sfbrowser.php", data:"a=ka&folder="+oSet.folder+"&file="+obj.file, dataType:"json", success:function(data, status){
					if (typeof(data.error)!="undefined") {
						if (data.error!="") {
							trace(data.error);
							alert(data.error);
						} else {
							trace(data.msg);
							$("#fbpreview").html("");
							mTr.remove();
						}
					}
				}});
			}
		});
		mTr.bind("mouseover", function() {
			$(this).addClass("over");
		}).bind("mouseout", function() {
			$(this).removeClass("over");
		}).bind("dblclick", function() {
			chooseFile($(this));
		}).bind("click", function() {
			if (!oSet.keys[16]) trace("todo: shift selection");
			if (!oSet.keys[17]) $("#sfbrowser tbody>tr").each(function(){if (mTr.get(0)!=$(this).get(0)) $(this).removeClass("selected")});
			$(this).toggleClass("selected");
			$("#fbpreview").html("");
			// todo: maybe select from mime
			if (("|"+oSet.img.join("|")+"|").indexOf("|"+$(this).find("td:eq(1)").text()+"|")!=-1) $("<img src=\""+oSet.folder+obj.file+"\" />").appendTo("#fbpreview").click(function(){$(this).parent().toggleClass("auto")});
			else if (oSet.ascii.indexOf($(this).find("td:eq(1)").text())!=-1) {
				$("#fbpreview").html(sLangPreviewText);
				$.ajax({type:"POST", url:"sfbrowser.php", data:"a=mizu&folder="+oSet.folder+"&file="+obj.file, dataType:"json", success:function(data, status){
						if (typeof(data.error)!="undefined") {
						if (data.error!="") {
							trace("ka error: "+data.error);
							alert(data.error);
						} else {
							trace(data.msg);
							$("#fbpreview").html("<pre><div>"+sLangPreviewPart.replace("#1",iPreviewBytes)+"</div>\n"+data.data.text.replace(/\>/g,"&gt;").replace(/\</g,"&lt;")+"</pre>");
						}
					}
				}});
			}
		});
		mTr.find("a.preview").bind("click", function(el) {
			window.open("sfbrowser.php?a=sui&file="+oSet.folder+obj.file,"_blank");
		});
		return mTr;
	}
	// loading
	function loading() {
		var iPrgMove = Math.ceil((new Date()).getTime()*.3)%512;
		$("#loadbar>div").css("backgroundPosition", "0px "+iPrgMove+"px");
		$("#loadbar:visible").each(function(){setTimeout(loading,20);});
	}
	// fileUpload
	function fileUpload() {
		trace("fileUpload");
		
		$("#loadbar").ajaxStart(function(){
			$(this).show();
			loading();
		}).ajaxComplete(function(){
			$(this).hide();
		});

		ajaxFileUpload({ // fu
			url:			"sfbrowser.php",
			secureuri:		false,
			fileElementId:	"fileToUpload",
			dataType:		"json",
			success: function (data, status) {
				if (typeof(data.error)!="undefined") {
					if (data.error!="") {
						trace("fu error: "+data.error);
						alert(data.error);
					} else {
						trace(data.msg);
						listAdd(data.data).trigger('click');
						$("#sfbrowser #fbtable").scrollTop(0);	// IE and Safari
						$("#sfbrowser tbody").scrollTop(0);		// Firefox
					}
					return false; // otherwise upload stays open...
				}
			},
			error: function (data, status, e){
				trace(e);
			}
		});
		return false;
	}
	// is numeric
	function isNum(n) {
		return (parseFloat(n)+"")==n;
	}
	// trace
	function trace(o) {
		if (window.console&&window.console.log) {
			if (typeof(o)=="string")	window.console.log(o);
			else						for (var prop in o) window.console.log(prop+": "+o[prop]);
		}
	};
	////////////////////////////////////////////////////////////////
	//
	// here starts copied functions from http://www.phpletter.com/Demo/AjaxFileUpload-Demo/
	// - changed iframe and form creation to jQuery notation
	//
	function ajaxFileUpload(s) {
		trace("ajaxFileUpload");
		var oSet = $.sfbrowser.settings;
        // todo: introduce global settings, allowing the client to modify them for all requests, not only timeout		
        s = jQuery.extend({}, jQuery.ajaxSettings, s);
		//
        var iId = new Date().getTime();
		var sFrameId = "jUploadFrame" + iId;
		var sFormId = "jUploadForm" + iId;
		var sFileId = "jUploadFile" + iId;
		//
		// create form
		var mForm = $("<form  action=\"\" method=\"POST\" name=\"" + sFormId + "\" id=\"" + sFormId + "\" enctype=\"multipart/form-data\"><input name=\"a\" type=\"hidden\" value=\"fu\" /><input name=\"folder\" type=\"hidden\" value=\""+oSet.folder+"\" /><input name=\"allow\" type=\"hidden\" value=\""+oSet.allow.join("|")+"\" /><input name=\"prevent\" type=\"hidden\" value=\""+oSet.prevent.join("|")+"\" /><input name=\"resize\" type=\"hidden\" value=\""+oSet.resize+"\" /></form>").appendTo('body').css({position:"absolute",top:"-1000px",left:"-1000px"});
		$("#"+s.fileElementId).before($("#"+s.fileElementId).clone(true).val("")).attr('id', s.fileElementId).appendTo(mForm);
		//
		// create iframe
		var mIframe = $("<iframe id=\""+sFrameId+"\" name=\""+sFrameId+"\"  src=\""+(typeof(s.secureuri)=="string"?s.secureuri:"javascript:false")+"\" />").appendTo("body").css({position:"absolute",top:"-1000px",left:"-1000px"});
		var mIframeIO = mIframe.get(0);
		//
        // Watch for a new set of requests
        if (s.global&&!jQuery.active++) jQuery.event.trigger("ajaxStart");
        var requestDone = false;
        // Create the request object
        var xml = {};
        if (s.global) jQuery.event.trigger("ajaxSend", [xml, s]);
        // Wait for a response to come back
        var uploadCallback = function(isTimeout) {			
			var mIframeIO = document.getElementById(sFrameId);
            try {				
				if(mIframeIO.contentWindow) {
					xml.responseText = mIframeIO.contentWindow.document.body?mIframeIO.contentWindow.document.body.innerHTML:null;
					xml.responseXML = mIframeIO.contentWindow.document.XMLDocument?mIframeIO.contentWindow.document.XMLDocument:mIframeIO.contentWindow.document;
				} else if(mIframeIO.contentDocument) {
					xml.responseText = mIframeIO.contentDocument.document.body?mIframeIO.contentDocument.document.body.innerHTML:null;
                	xml.responseXML = mIframeIO.contentDocument.document.XMLDocument?mIframeIO.contentDocument.document.XMLDocument:mIframeIO.contentDocument.document;
				}						
            } catch(e) {
				jQuery.handleError(s, xml, null, e);
			}
            if (xml||isTimeout=="timeout") {				
                requestDone = true;
                var status;
                try {
                    status = isTimeout != "timeout" ? "success" : "error";
                    // Make sure that the request was successful or notmodified
                    if (status!="error") {
                        // process the data (runs the xml through httpData regardless of callback)
                        var data = uploadHttpData(xml, s.dataType);    
                        // If a local callback was specified, fire it and pass it the data
                        if (s.success) s.success(data, status);
                        // Fire the global callback
                        if (s.global) jQuery.event.trigger("ajaxSuccess", [xml, s]);
                    } else {
                        jQuery.handleError(s, xml, status);
					}
                } catch(e) {
                    status = "error";
                    jQuery.handleError(s, xml, status, e);
                }

                // The request was completed
                if (s.global) jQuery.event.trigger("ajaxComplete", [xml, s]);

                // Handle the global AJAX counter
                if (s.global && ! --jQuery.active) jQuery.event.trigger("ajaxStop");

                // Process result
                if (s.complete) s.complete(xml, status);

				mIframe.unbind();

                setTimeout(function() {
					try {
						mIframe.remove();
						mForm.remove();
					} catch(e) {
						jQuery.handleError(s, xml, null, e);
					}
				}, 100);

                xml = null;
            }
        }
        // Timeout checker
        if (s.timeout>0) {
            setTimeout(function() {
                // Check to see if the request is still happening
                if(!requestDone) uploadCallback("timeout");
            }, s.timeout);
        }
        try {
			mForm.attr("action", s.url).attr("method", "POST").attr("target", sFrameId).attr("encoding", "multipart/form-data").attr("enctype", "multipart/form-data").submit();
        } catch(e) {			
            jQuery.handleError(s, xml, null, e);
        }
		mIframe.load(uploadCallback);
        return {abort: function () {}};
    }
	function uploadHttpData(r, type) {
        var data = !type;
        data = type=="xml" || data?r.responseXML:r.responseText;
        // If the type is "script", eval it in global context
        if (type=="script")	jQuery.globalEval(data);
        // Get the JavaScript object, if JSON is used.
        if (type=="json")	eval("data = " + data);
        // evaluate scripts within html
        if (type=="html")	jQuery("<div>").html(data).evalScripts();
		//alert($('param', data).each(function(){alert($(this).attr('value'));}));
        return data;
    }
	////////////////////////////////////////////////////////////////
	// set functions
//	$.sfbrowser = $.fn.fb = $.fn.sfbrowser;
//	$.sfbrowser.fu = $.fn.fb = $.fn.sfbrowser;
})(jQuery);
/*!
* jQuery SFBrowser
*
* Version: 3.1.3
*
* Copyright (c) 2010 Ron Valstar http://www.sjeiti.com/
*
* Dual licensed under the MIT and GPL licenses:
*   http://www.opensource.org/licenses/mit-license.php
*   http://www.gnu.org/licenses/gpl.html
*//*
*
* description
*   - A file browsing and upload plugin. Returns a list of objects with additional information on the selected files.
*
* requires
*   - jQuery 1.2+
*   - PHP5 (or any other server side script if you care to write the connectors)
*
* features
*   - ajax file upload
*	- optional as3 swf upload (queued multiple uploads, upload progress, upload canceling, selection filtering, size filtering)
*   - localisation (English, Dutch or Spanish)
*	- server side script connector
*	- plugin environment (with filetree and imageresize plugin)
*	- data caching (minimal server communication)
*   - sortable file table
*   - file filtering
*   - file renameing
*   - file duplication
*   - file download
*   - file/folder context menu
*   - file preview (image, audio, video, archive, text/ascii and swf)
*	- folder creation
*   - multiple files selection (not in IE for now)
*	- inline or overlay window
*	- window dragging and resizing
*	- cookie for size, position and path
*	- keyboard shortcuts
*	- key file selection
*
* how it works
*   - sfbrowser returns a list of file objects.
*	  A file object contains:
*		 - file(String):		The file including its path
*		 - mime(String):		The filetype
*		 - rsize(int):			The size in bytes
*		 - size(String):		The size formatted to B, kB, MB, GB etc..
*		 - time(int):			The time in seconds from Unix Epoch
*		 - date(String):		The time formatted in "j-n-Y H:i"
*		 - width(int):			If image, the width in px
*		 - height(int):			If image, the height in px
*
* aknowlegdments
*   - initial ajax file upload scripts from http://www.phpletter.com/Demo/AjaxFileUpload-Demo/
*	- Spanish translation: Juan Razeto
*
* todo:
*	- update fileInfo after edit (ascii or image)
*	- it should be possible to rename from ascii to ascii (html to htm, or maybe even jar to zip)
*	- implement sheet.png (ie multiple icons into one png)
*	- remove pending uploads on close
*	- sort uploading files on top
*	- multiple file deletion (recursive folder deletion)
*   - new: general filetype filter
*   - fix: IE swf upload
*   - new: folder information such as number of files (possibly add to filetree)
*	- oSettings.file to work with multiple files
*	o table
*		- possibly replace table for http://code.google.com/p/flexigrid/, or do it myself and fix the scrolling, structure follows function
*		- IE: fix IE and Safari scrolling (table header moves probably due to absolute positioning of parents), or simply don't do xhtml (make two tables)
*		- add: drag and drop files to folders
*		- maybe: thumbnail view
*		- fix: since resizing is possible abbreviating long filenames does not cut it (...)
*		o multiple file selection
*			- add: make text selection in table into multiple file selection
*			- FF: multiple file selection: disable table cell highlighting (border)
*			- IE: fix multiple file selection
*	o preview
*		- add: image preview: no-scaling on smaller images
*		- add: pdf and doc preview (http://davidwalsh.name/read-pdf-doc-file-php)
*		- add: misc archive format preview (tar, tar.gz, iso, arj, sit)
*		- test: rar preview (implemented but was unable to install php_rar)
*	- add: style option: new or custom css files
*	- fix: Opera sucks (or let Opera fix itself)
*	- code: check what timeout code in upload code really does
*	- fix: figure out IE slowness by disabling half transparent bg (replace with gif)
*   - new: add mime instead of extension (for mac)
*
* in this update:
*		- fixed json file-list value 'if' to 'i_' (error occurs for file # 85)
*		- some refactoring
*		- tested with jQuery 1.4.4
*		- fixed cookie 1px height bug
*		- better move/resize handling
*
* in last update:
*		- slight css3 style update
*		- small bugfixes in image plugin
*		- added boolean bIsOpen to prevent keyboard shortcuts from firing
*/
;(function($) {
	// private variables
	var oSettings = {};
	var ss = oSettings;
	var aSort = [];
	var iSort = 0;
	var bHasImgs = false;
	//
	var aPath = [];
	var oTree = {};
	//
	var bOverlay = false;
	//
	var sFolder;
	var sReturnPath;
	//
	var oConstraint;
	//
	var sBodyOverflow = "auto";
	//
	var bIsOpen = false;
	//
	// display
	var $Document = $(document);
	var $Window;
	var $Body;
	var $SFB;
	var $SFBWin;
	var $TableH;
	var $Table;
	var $TbBody;
	var $TrLoading;
	//
	var oCookie;
	//
	// regexp
	var oReg = {
		 fileNameNoExt: /(.*)[\/\\]([^\/\\]+)\.\w+$/
		,fileNameWiExt: /(.*)[\/\\]([^\/\\]+\.\w+)$/
	}
//	var rFileNameNoExt = /(.*)[\/\\]([^\/\\]+)\.\w+$/;
//	var rFileNameWiExt = /(.*)[\/\\]([^\/\\]+\.\w+)$/;
	//
	// default settings
	$.sfbrowser = {
		 id: "SFBrowser"
		,version: "3.1.3"
		,copyright: "Copyright (c) 2007 - 2010 Ron Valstar"
		,uri: "http://sfbrowser.sjeiti.com/"
		,defaults: {
			 title:		""						// the title
			,select:	function(a){trace(a)}	// calback function on choose
			,selectparams: null					// parameter object for select function
			,selectnum:	0						// number of selectable files (uint) 0==any
			,file:		""						// selected file
			,folder:	""						// subfolder (relative to base), all returned files are relative to base
			,dirs:		true					// allow visibility and creation/deletion of subdirectories
			,upload:	true					// allow upload of files
			,swfupload:	false					// use swf uploader instead of form hack
			,allow:		[]						// allowed file extensions
			,resize:	null					// resize images after upload: array(width,height) or null
			,inline:	"body"					// a JQuery selector for inline browser
			,fixed:		false					// keep the browser open after selection (only works when inline is not "body")
			,cookie:	false					// use a cookie to remeber path, x, y, w, h
			,preview:	true					// enable small preview window for txt, img, video etc...
			,bgcolor:	"#000"					// 
			,bgalpha:	.5						// 
			,x:			null					// x position, centered if left null
			,y:			null					// y position, centered if left null
			,w:			640						// width
			,h:			480						// height
			// basic control (normally no need to change)
			,img:		["gif","jpg","jpeg","png"]
			,ascii:		["txt","xml","html","htm","eml","ffcmd","js","as","php","css","java","cpp","pl","log"]
			,movie:		["mp3","mp4","m4v","m4a","3gp","mov","flv","f4v"]
			,archive:	["zip","rar"]
			// set from init, explicitly setting these from js can lead to unexpected results.
			,sfbpath:	"sfbrowser/"			// path of sfbrowser (relative to the page it is run from)
			,base:		"../data/"				// upload folder (relative to sfbpath)
			,prefx:	""							// modify path to ajax script, file path and preview
			,deny:		[]						// not allowed file extensions
			,icons:		[]						// list of existing file icons 
			,previewbytes:600					// amount of bytes for ascii preview
			,connector:	"php"					// connector file type (php)
			,lang:		{}						// language object
			,plugins:	[]						// plugins
			,maxsize:	2097152					// upload_max_filesize in bytes
			,debug:		false					// debug (allows trace to console)
		}
		// add language on the fly
		,addLang: function(oLang) {
			for (var sId in oLang) $.sfbrowser.defaults.lang[sId] = oLang[sId];
		}
		// swf upload functions (ExternalInterface) 446
		,swfInit: function() {trace("swfInit");}
		,ufileSelected: function(s) {
			trace("ufileSelected: "+s); // TRACE ### ufileSelected
			var bPrcd = true;
			if (getPath().contents[s]!==undefined&&!confirm(oSettings.lang.fileExistsOverwrite)) bPrcd = false;
			if (bPrcd) $("#swfUploader").get(0).doUpload(s);
			else $("#swfUploader").get(0).cancelUpload(s);
		}
		,ufileTooBig: function(s) {
			alert(oSettings.lang.fileTooBig.replace("#1",s).replace("#2",format_size(oSettings.maxsize,0)));
		}
		,ufileOpen: function(s) {
			trace("ufileOpen: "+s); // TRACE ### ufileOpen
			var oExists = getPath().contents[s];
			if (oExists) oExists.tr.remove(); // $$ overwriting existing files and canceling while uploading will cause the old file to disappear from view
			var mTr = listAdd({file:s,mime:"upload",rsize:0,size:"",time:0,date:"",width:0,height:0}).addClass("uploading");
		}
		,ufileProgress: function(f,s) {
			var oExists = getPath().contents[s];
			var mPrg = oExists.tr.find(".progress");
			var sPerc = Math.round(f*100)+"%";
			mPrg.find("span").text(sPerc);
			mPrg.find("div").css({width:sPerc});
		}
		,ufileCompleteD: function(o) {
			trace("ufileCompleteD: "+o); // TRACE ### o
			trace(o); // TRACE ### o
			getPath().contents[o.data.file].tr.remove();
			listAdd(o.data,1).trigger('click');
		}
		,getPath: function() {
			trace("getPath"); // TRACE ### o
			$("#swfUploader").get(0).setPath(aPath.join(""));
		}
	};
	// init
	$(function() {
		trace($.sfbrowser.id+" "+$.sfbrowser.version,true);
	});
	// call
	$.fn.extend({
		sfbrowser: function(_settings) {
			$.extend(oSettings, $.sfbrowser.defaults, _settings);
			ss.connbase = "connectors/"+ss.connector+"/sfbrowser."+ss.connector;
			ss.conn = ss.prefx+ss.sfbpath+ss.connbase;
			//
			trace("oSettings.conn: "+oSettings.conn); // TRACE ### oSettings.conn
			//
			// extra vars in debug mode
			if (ss.debug) {
				$.sfbrowser.tree = oTree;
				$.sfbrowser.path = aPath;
			}
			//
			// basic vars
			$Window = $(window);
			$Body = $("body");
			//
			// set constraints
			oConstraint = {
				 mnx: 0
				,mny: 0
				,mxx: $Window.width()  - ss.w
				,mxy: $Window.height() - ss.h
				,mnw: 244
				,mnh: 275
				,mxw: $Window.width()
				,mxh: $Window.height()
			};
			//
			// try cookie for vars
			getSfbCookie();
			//
			//////////////////////////// (clear) start vars
			aSort = [];
			bHasImgs = ss.allow.length===0||unique(copy(ss.img).concat(ss.allow)).length<(ss.allow.length+ss.img.length);
			aPath = [];
			sFolder = ss.base+ss.folder;
			bOverlay = ss.inline=="body";
			if (bOverlay) ss.fixed = false;
			//
			// path vs cookie (we'll not use the cookie path if it is not within the parsed path)
			if (oCookie&&oCookie.path&&oCookie.path.length>0) {
				if (sFolder==oCookie.path[0]) {
					aPath = oCookie.path;
					sFolder = aPath.pop();
				}
			}
			//
			// fix path and base to relative
			var aFxSfbpath =	ss.sfbpath.split("/");
			var aFxBase =		ss.base.split("/");
			var iFxLen = Math.min(aFxBase.length,aFxSfbpath.length);
			var iDel = 0;
			for (var i=0;i<iFxLen;i++) {
				var sFxFolder = aFxBase[i];
				if (sFxFolder==".."&&aFxSfbpath.length>0) {
					while (true) {
						var sRem = aFxSfbpath.pop();
						if (sRem!="") {
							iDel++;
							break;
						}
					}
				} else if (sFxFolder!="") {
					aFxBase = aFxBase.splice(iDel);
					break;
				}
			}
			sReturnPath = (aFxSfbpath.join("/")+"//"+aFxBase.join("/")).replace(/(\/+)/,"/").replace(/(^\/+)/,"");
			//
			//
			//
			//////////////////////////// file browser
			$SFB =		$(ss.browser);
			$SFBWin =	$SFB.find("#fbwin");
			$TableH =	$SFBWin.find("#fbtable");
			$Table =	$TableH.find("table");
			$TbBody =	$Table.find("tbody");
			// top menu
			$SFB.find("div.sfbheader>h3").html((ss.title==""?ss.lang.sfb:ss.title)+(ss.debug?" <span>debug mode</span>":""));
			$SFB.find("div#loadbar>span").text(ss.lang.loading);
			$SFB.find("#fileToUpload").change(fileUpload);
			var mTopA = $SFB.find("ul#sfbtopmenu>li>a");
			if (ss.dirs)	mTopA.filter(".newfolder").click(addFolder).attr("title",ss.lang.newfolder).find("span").text(ss.lang.newfolder);
			else			mTopA.filter(".newfolder").parent().remove();
			if (ss.upload)	mTopA.filter(".upload").attr("title",ss.lang.upload).find("span").text(ss.lang.upload);
			else			mTopA.filter(".upload").parent().remove();
			if (!ss.fixed)	mTopA.filter(".cancelfb").click(closeSFB).attr("title",ss.lang.cancel).find("span").text(ss.lang.cancel);
			else			mTopA.filter(".cancelfb").parent().remove();
			if (!ss.fixed)	mTopA.filter(".maximizefb").click(maximizeSFB).attr("title",ss.lang.maximize||'').find("span").text(ss.lang.maximize||'');
			else			mTopA.filter(".maximizefb").parent().remove();
			// table headers
			var mTh = $SFB.find("table#filesDetails>thead>tr>th");
			mTh.eq(0).text(ss.lang.name);
			mTh.eq(1).text(ss.lang.type);
			mTh.eq(2).text(ss.lang.size);
			mTh.eq(3).text(ss.lang.date);
			mTh.eq(4).text(ss.lang.dimensions);
			if (!bHasImgs) mTh.eq(4).remove();
			mTh.filter(":not(:last)").each(function(i,o){
				$(this).click(function(){sortFbTable(i)});
			}).append("<span>&nbsp;</span>");
			// preview
			if (!ss.preview) $SFB.find("#fbpreview").remove();
			trace("ss.preview: "+ss.preview);
			// big buttons
			trace("$SFBWin.find(\"div.choose\").: "+$SFBWin.find("div.choose").length); // TRACE ### $SFBWin.find("div.choose").
			$SFBWin.find("div.choose").click(chooseFile).text(ss.lang.choose).click(function(e){trace("click")}).mouseover(function(e){trace("mouseover")});
			$SFBWin.find("div.cancelfb").click(closeSFB).text(ss.lang.cancel);
			$SFBWin.find("#sfbfooter").html('<a href="'+$.sfbrowser.uri+'">'+$.sfbrowser.id+" "+$.sfbrowser.version+" &nbsp; &nbsp; &nbsp; &nbsp; "+$.sfbrowser.copyright+'</a>');
			// loading msg
			$TrLoading = $TbBody.find("tr").clone();
			// background color
			$SFB.find("#fbbg").css({
				 backgroundColor: ss.bgcolor
				,opacity: ss.bgalpha
				,filter: "alpha(opacity="+(100*ss.bgalpha)+")"
			});
			//
			//
			// remove any existing instances and add...
			$SFB.remove();
			$SFB.appendTo(ss.inline);
			//
			//
			// context menu
			addContextItem("choose",		ss.lang.choose,		function(){chooseFile()});
			addContextItem("rename",		ss.lang.rename,		function(){renameSelected()});
			addContextItem("duplicate",		ss.lang.duplicate,	function(){duplicateFile()});
			addContextItem("preview",		ss.lang.view,		function(){$TbBody.find("tr.selected:first a.preview").trigger("click")});
			addContextItem("filedelete",	ss.lang.del,		function(){$TbBody.find("tr.selected:first a.filedelete").trigger("click")});
			$SFB.click(function(){
				$("#sfbcontext").slideUp("fast");
			});
			//
			//////////////////////////// window positioning and sizing
			if (bOverlay) { // resize and move window
				$Window.bind("resize", resizeBrowser);

				$SFBWin.attr("unselectable","on").css("MozUserSelect","none").bind("selectstart.ui",function(){return false;}); // $$ what's that last string?

				$SFB.find("h3").attr("title",ss.lang.dragMe).mousedown(moveWindowDown);
				$SFB.find("div#resizer").attr("title",ss.lang.dragMe).mousedown(resizeWindowDown);

				//$SFBWin.disableSelection().draggable({
				//	 handle:$SFB.find("h3")
				//	,containment:'parent'
				//}).resizable(); // resizable fails miserably so fuck jquery.ui altogether

				if (ss.x==null) ss.x = Math.round($Window.width()/2-$SFBWin.width()/2);
				if (ss.y==null) ss.y = Math.round($Window.height()/2-$SFBWin.height()/2);
				$SFBWin.css({ top:ss.y, left:ss.x, width:ss.w, height:ss.h });
			} else { // static inline window
				trace("sfb inline");
				$SFB.find("#fbbg").remove();
				$SFB.find("div#resizer").remove();
				$SFB.find("div.cancelfb").remove();
				$SFB.css({position:"relative",width:"auto",heigth:"auto"});
				$SFBWin.css({position:"relative",border:"0px"});
				var mPrn = $(ss.inline);
				resizeWindow(0,mPrn.width(),mPrn.height());
			}
			//
			//////////////////////////// keys
			// ESC		27		close filebrowser
			// (F1		-		help)				#impossible: F1 browser help
			// F2		113		rename
			// F4		115		edit				#unimplemented
			// (F5		-		copy)				#impossible: F5 browser reloads
			// (F6		-		move)				
			// (F7		-		create directory)	
			// F8		119		delete				#unimplemented
			// F9		120		properties			#unimplemented
			// (F10		-		quit)				
			// F11		122							#impossible: F5 browser fullscreen
			// F12		123							
			// 13		RETURN	choose file
			// 32		SPACE	select file			#unimplemented
			// SHIFT	65		multiple selection	#unimplemented
			// CTRL		17		multiple selection
			// CTRL-A	65+17	select all
			// CTRL-Q	65+81	close filebrowser
			// CTRL-F	65+70	open filebrowser	$$ only after first run
			// left		37
			// up		38
			// right	39
			// down		40
			ss.keys = [];
			$Window.keydown(function(e){
				ss.keys[e.keyCode] = true;
				//
				var iNumDown = 0;
				$.each(ss.keys,function(i,o){if(o)iNumDown++});
				//
				// selection by char a:65 z:90
				// $$ checkRename doet rename disabelen
//				if (iNumDown==1&&!checkRename()&&e.keyCode>=65&&e.keyCode<=90) {
				if (bIsOpen&&iNumDown==1&&$TbBody.find("tr>td>input").length==0&&e.keyCode>=65&&e.keyCode<=90) {
					var sChar = ("abcdefghijklmnopqrstuvwxyz").substr(e.keyCode-65,1);
					var mSel = $TbBody.find("tr.selected:first");
					var aTbr = $TbBody.find("tr");
					var iInd = aTbr.index(mSel);
					if (iInd==-1) iInd = 0;
					var iTbr = aTbr.length;
					for (var i=1;i<iTbr;i++) {
						var mChk = $(aTbr[(i+iInd)%iTbr]);
						if (mChk.attr("id").substr(0,1).toLowerCase()==sChar) {
							mChk.mouseup(clickTr).mouseup();
							return false;
						}
					}
				}
				// single key functions
				switch (e.keyCode) {
					case 13: if (bIsOpen) chooseFile(); break; //$$ disable in pluginmode
				}
				// CTRL functions
				if (ss.keys[17]) {
					var bReturn = false;
					switch (e.keyCode) {
						case 81: if (bIsOpen) closeSFB(); break;
						case 65: if (bIsOpen) $TbBody.find("tr").each(function(){$(this).addClass("selected")}); break;
						case 70: if (!bIsOpen&&$SFB.length==0) $.sfb(ss); break;
						default: bReturn = true;
					}
					if (!bReturn) return false;
				}
				//if (e.keyCode==70&&ss.keys[17]) {
				//	if ($SFB.length==0) $.sfb();
				//}
			});
			$Window.keyup(function(e){
				//trace("key: "+e.keyCode+" ")
				if (bIsOpen&&ss.keys[113])	renameSelected();
				if (bIsOpen&&ss.keys[27])		closeSFB();
				ss.keys[e.keyCode] = false;
				return false;
			});
			//
			//////////////////////////// plugins
			var oThis = {
				// functions
				 trace:				trace
				,openDir:			openDir
				,closeSFB:			closeSFB
				,addContextItem:	addContextItem
				,listAdd:			listAdd
				,file:				file
				,lang:				lang
				,resizeWindowDown:	resizeWindowDown
				,moveWindowDown:	moveWindowDown
				,resizeWindow:		resizeWindow
				,onError:			onError
				// variables
				,aPath:		aPath
				,bOverlay:	bOverlay
				,oSettings:	ss
				,oTree:		oTree
				,mSfb:		$SFB // todo: refactor var name in plugin
				,oReg:		oReg
			};
			$.each( ss.plugins, function(i,sPlugin) { $.sfbrowser[sPlugin](oThis) });
			//
			// swf uploader (timeout to ensure width and height are set)
			//ss.swfupload = true;
			if (ss.swfupload) {
				$("<br/>").animate({"foo":1},{"duration":1,"complete":function(){
					trace("sfb swfupload init");
					$SFB.find("#fileio").remove();
					var mAup = $SFB.find("#sfbtopmenu a.upload");
					mAup.append("<div id=\"swfUploader\"></div>");
					swfobject.embedSWF(
						 ss.sfbpath+"uploader.swf"
						,"swfUploader"
						,(mAup.width()+10)+"px" // +10 accounts for padding
						,mAup.height()+"px"
						,"9.0.0",""
						,{ // flashvars
							 debug:		ss.debug
							,maxsize:	ss.maxsize
							,uploadUri:	ss.connbase//"../../"+ss.conn///////#################################### ../ is the bastard
/*

web/wp-admin/
web/wp-content/uploads/
SFB_PATH	"../wp-content/plugins/sfbrowser/"
SFB_BASE	"../../uploads/"
"../../"+ss.conn		(ss.conn: ../wp-content/plugins/sfbrowser/connectors/php/sfbrowser.php)


web/
web/data/
SFB_PATH	"sfbrowser/"
SFB_BASE	"../data/"
"../"+ss.conn		(ss.conn: sfbrowser/connectors/php/sfbrowser.php)

*/
							,action:	"swfUpload"
							,folder:	aPath.join("")
							,allow:		ss.allow.join("|")
							,deny:		ss.deny.join("|")
							,resize:	ss.resize
						},{menu:"false",wmode:"transparent"}
					);
				}});
			}
			//
			//
			var mUpbut = $SFB.find("form#fileio");
			var mAUpbut = $SFB.find("#sfbtopmenu a.upload");
			//
			// debug
			//$TbBody.parent().parent().hide();
			if (ss.debug) mUpbut.css({opacity:".5",filter:"alpha(opacity=50)"});
			//
			// IE8 upload css fix $$ IE does not yet render swf upload
			$.browser.msie&&$.browser.version>=8&&mUpbut.css({
				 top:		"-15px"
				,width:		"90px"
			}).find("input").css({
				 fontSize:	"12px"
			});
			//
			//////////////////////////// start
			openDir(sFolder);
			openSFB();
			trace("SFBrowser open ("+(ss.swfupload?"swf":"normal")+" upload, "+ss.plugins+")",true);
		}
	});

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////////////////////////////// private functions
	//
	// open
	function openSFB() {
		$SFB.find("#fbbg").slideDown();
		$SFBWin.slideDown("normal",function(){
			resizeBrowser();
			resizeWindow();
			if (ss.cookie&&!oCookie) setSfbCookie();
		});
		if (bOverlay) {
			sBodyOverflow = $Body.css("overflow");
			$Body.css({overflow:"hidden"});
		}
		bIsOpen = true;
	}
	//
	// close
	function closeSFB() {
		trace("sfb close");
		// $$ remove all pending uploads
		if (ss.cookie) setSfbCookie();
		$("#sfbrowser #fbbg").fadeOut();
		$SFBWin.slideUp("normal",function(){$SFB.remove();});
		if (bOverlay) $Body.css({overflow:sBodyOverflow}).scrollTop($Body.scrollTop()+1);
		bIsOpen = false;
	}
	// sortFbTable
	function sortFbTable(nr) {
		if (nr!==null) {
			iSort = nr;
			aSort[iSort] = aSort[iSort]=="asc"?"desc":"asc";
		} else {
			if (!aSort[iSort]) aSort[iSort] = "asc";
		}
		$TbBody.find("tr.folder").tsort("td:eq(0)[abbr]",{attr:"abbr",order:aSort[iSort]});
		$TbBody.find("tr:not(.folder)").tsort("td:eq("+iSort+")[abbr]",{attr:"abbr",order:aSort[iSort]});
		$SFB.find("thead>tr>th>span").each(function(i,o){
//			$(this).css({backgroundPosition:(i==iSort?5:-9)+"px "+(aSort[iSort]=="asc"?4:-96)+"px"})
			$Span = $(this);
			if (i==iSort)	$Span.addClass('sort');
			else			$Span.removeClass('sort');
			if (aSort[iSort]=="asc")	$Span.addClass('asc');
			else						$Span.removeClass('asc');
		});
	}
	// fill list
	function fillList(contents) {
		trace("sfb fillList "+aPath);
		$TbBody.children().remove();
		$("#fbpreview").html("");
		aSort = [];
		//
		var oCTree = getPath();
		oCTree.filled = true;
		//
		//
		if (ss.file!="") { // find selected file // #@@##@!$#@! bloody figure out why file not has ../ and base has!!!!!!!!!
			// make path class to ease the following:
			// find size of ss.sfbpath to pre-pop from ss.base (../) and substract that from ss.file
			var iSfbLn = 0;
			var aSfbP = ss.sfbpath.split("/");
			$.each(aSfbP,function(i,s){if(s!="")iSfbLn++});
			var sPth = "";
			$.each(aPath,function(i,sPath){sPth+=sPath+"///"});
			sPth = sPth.replace(/(\/+)/g,"/");
			aSPth = sPth.split("/");
			sRpth = "";
			$.each(aSPth,function(i,sPath){if(i>=iSfbLn)sRpth+=sPath+"/"});
			sRpth = sRpth.replace(/(\/+)/g,"/");
			var sSelFileName = ss.file.replace(sRpth,"");
			var aSeF = ss.file.split("/");
			var iDff = aSeF.length-aPath.length-1;
		}
		//
		$.each( contents, function(i,oFile) {
			// todo: logical operators could be better
			var bDir = (oFile.mime=="folder"||oFile.mime=="folderup");
			if ((ss.allow.indexOf(oFile.mime)!=-1||ss.allow.length===0)&&ss.deny.indexOf(oFile.mime)==-1||bDir) {
				if ((bDir&&ss.dirs)||!bDir) {
					var mTr = listAdd(oFile);
					// find selected file
					if (ss.file!=""&&sSelFileName==oFile.file) {
						mTr.animate({"foo":1},{ // select by timeout to prevent error
							"duration":1
							,"complete":function(){
								mTr.mouseup(clickTr).mouseup();
								ss.file = "";
							}
						});
					}
				}
			}
		});
		//
		if (aPath.length>1&&!oCTree.contents[".."]) listAdd({file:"..",mime:"folderup",rsize:0,size:"-",time:0,date:""});
//		$("#sfbrowser thead>tr>th:eq(0)").trigger("click");
		$SFBWin.find("thead>tr>th:eq(0)").trigger("click");
		//
		// plugin
		$.each( ss.plugins, function(i,sPlugin) {
			if ($.sfbrowser[sPlugin].fillList) $.sfbrowser[sPlugin].fillList(contents);
		});
		//
		if (ss.file!=""&&iDff>0) openDir(aSeF[aPath.length]);
	}
	// add item to list
	function listAdd(obj,sort) {
		getPath().contents[obj.file] = obj;
		//
		var bUpload = obj.mime=="upload";
		var bFolder = obj.mime=="folder";
		var bUFolder = obj.mime=="folderup";
		var sMime = bFolder||bUFolder?ss.lang.folder:obj.mime;
		var sTr = "<tr id=\""+obj.file+"\" class=\""+(bFolder||bUFolder?"folder":"file")+"\">";
//		var iHo = -16*(obj.mime.charCodeAt(0)-97);
//		var iVo = -16*(obj.mime.charCodeAt(1)-97);
//		sTr += "<td abbr=\""+obj.file+"\" title=\""+obj.file+"\" class=\"icon\" ><span style=\"background: transparent url("+ss.sfbpath+"icons/fileSheet.png) "+iHo+"px "+iVo+"px no-repeat;\" />"+obj.file+"</td>";
		sTr += "<td abbr=\""+obj.file+"\" title=\""+obj.file+"\" class=\"icon\" style=\"background-image:url("+ss.sfbpath+"icons/"+(ss.icons.indexOf(obj.mime)!=-1?obj.mime:"default")+".gif);\">"+obj.file+"</td>";
		if (bUpload) {
			sTr += "<td abbr=\"upload progress\" colspan=\"4\"><div class=\"progress\"><div></div><span>0%</span><div></td>";
			sTr += "<td><a class=\"sfbbutton cancel\" title=\""+ss.lang.fileUploadCancel+"\"><span>"+ss.lang.fileUploadCancel+"</span></a></td>";
		} else {
			sTr += "<td abbr=\""+obj.mime+"\">"+sMime+"</td>";
			sTr += "<td abbr=\""+obj.rsize+"\">"+obj.size+"</td>";
			sTr += "<td abbr=\""+obj.time+"\" title=\""+obj.date+"\">"+obj.date.split(" ")[0]+"</td>";
			var bVImg = (obj.width*obj.height)>0;
			sTr += (bHasImgs?("<td"+(bVImg?(" abbr=\""+(obj.width*obj.height)+"\""):"")+">"+(bVImg?(obj.width+"x"+obj.height+"px"):"")+"</td>"):"");
			sTr += "<td>";
			if (!(bFolder||bUFolder||bUpload)) sTr += "	<a onclick=\"\" class=\"sfbbutton preview\" title=\""+ss.lang.view+"\">&nbsp;<span>"+ss.lang.view+"</span></a>";
			if (!(bUFolder||bUpload)) sTr += "	<a onclick=\"\" class=\"sfbbutton filedelete\" title=\""+ss.lang.del+"\">&nbsp;<span>"+ss.lang.del+"</span></a>";
			sTr += "</td>";
		}
		sTr += "</tr>";
		// 
		var mTr = $(sTr).prependTo($TbBody);
		//mTr.draggable({opacity:0.7,helper:'clone'}); // $$ add drop onto folder moves file
		//
		//mTr.find("td").wrapInner("<div></div>");
		//$("#sfbrowser thead>tr").remove();
		//
		obj.tr = mTr;
		mTr.find("a.filedelete").click(deleteFile);
		mTr.find("a.preview").click(showFile);
		mTr.find("a.cancel").click(function(e){
				$("#swfUploader").get(0).cancelUpload($(this).parent().parent().attr("id"));
				mTr.remove();
			});
		//mTr.find("td:last").css({textAlign:"right"}); // IE fix
		mTr.folder = bFolder||bUFolder;
		if (!bUpload) {
			mTr.mousedown(clickTrDown).mouseover( function() {
				mTr.addClass("over");
			}).mouseout( function() {
				mTr.removeClass("over");
			}).dblclick( function(e) {
				chooseFile($(this));
			})
		}
//			function(e) {
//				mTr.mouseup( clickTr );
//			}
		mTr[0].oncontextmenu = function(e) {
			return false;
		};
		// plugin
		$.each( ss.plugins, function(i,sPlugin) {
			if ($.sfbrowser[sPlugin].listAdd) $.sfbrowser[sPlugin].listAdd(obj);
		});
		//
		// select and sort
		if (sort&&sort>0) {
			aSort[iSort] = aSort[iSort]=="asc"?"desc":"asc";
			sortFbTable(iSort);
			mTr.mousedown().mouseup();
			$TableH.scrollTop(0);	// IE and Safari
			$TbBody.scrollTop(0); // Firefox
		}
		//
		return mTr;
	}
	// clickTrDown
	var oDragTr;
	var $DragTr;
	function clickTrDown(e) {
		$Tr = $(e.currentTarget);
		$Tr.mouseup( clickTr );
		// drag and drop
		trace("clickTrDown\n"); // TRACE ### clickTr
		// screenX:	716
		// screenY:	191
		// pageX:	716
		// pageY:	3767
		// offsetX:	53
		// offsetY:	4
		// layerX:	53
		// layerY:	3717
		// clientX:	716
		// clientY:	106
		oDragTr = {
			 screenX:	e.screenX
			,screenY:	e.screenY
			,pageX:		e.pageX
			,pageY:		e.pageY
			,offsetX:	e.offsetX
			,offsetY:	e.offsetY
			,layerX:	e.layerX
			,layerY:	e.layerY
			,clientX:	e.clientX
			,clientY:	e.clientY
		}
//		trace(oDragTr); // TRACE ### oDragTr
		$DragTr = $Tr;
		$Document.mousemove(mouseMoveTr);
		$Document.mouseup(clearMoveTr);
	}
	// mouseMoveTr
	var $DragTrTable;
	function mouseMoveTr(e) {
		if ($DragTrTable===undefined) {
			$DragTrTable = $('<table id="sfbDragSelect"></table>').appendTo($Body);
			$DragTrTable.append($DragTr.clone());
		} else {
			var iX = e.pageX;// e.offsetX-oDragTr.offsetX;
			var iY = e.pageY;// e.offsetY-oDragTr.offsetY;
			$DragTrTable.css({
				 position:	"absolute"
				,left:		iX-100+"px"
				,top:		iY-7+"px"
				,zIndex:	"500"
			});
		}
	}
	// clearMoveTr
	function clearMoveTr() {
		$Document.unbind('mouseup',clearMoveTr);
		$Document.unbind('mousemove',mouseMoveTr);
		if ($DragTrTable!==undefined) {
			var oFromFile = file($DragTrTable.find("tr"));
			$DragTrTable.remove();
			$DragTrTable = undefined;
			var $ToTr = $Body.find("tr.over");
			if ($ToTr.length>0) {
				var oToFile = file($ToTr);
				if (oToFile.mime=="folder"||oToFile.mime=="folderup") {
					trace("drop: "+oFromFile.file+" into "+oToFile.file);//////////////////////////////////////////////////////////////////////////////////////DROP
				}
			}
		}
	}
	// clickTr: left- or rightclick table row
	function clickTr(e) {
		trace("clickTrUp\n\n"); // TRACE ### clickTr
		//
		clearMoveTr();
		//
		var mTr = $(this);
		mTr.unbind("mouseup");
		var oFile = file(mTr);
		var bFolder = oFile.mime=="folder";
		var bUFolder = oFile.mime=="folderup";
		var sFile = oFile.file;
		var bRight = e.button==2;
		var mCntx = $("#sfbcontext");
		var bCTRL = ss.keys[17];
		if (mTr.hasClass("uploading")) return false;
		// check if place is in view
		var mTbd = mTr.parent();
		var iTrY = mTr[0].offsetTop;
		var iTbH = mTbd.height();
		var iTsc = mTbd.scrollTop();
		//trace("\niTrY: "+iTrY+"  iTbH: "+iTbH+"  iTsc: "+iTsc+"  a: "+mTr[0].offsetTop);
		if (iTrY<iTsc||iTrY>(iTsc+iTbH)) {
			var iAdd = iTrY-(iTsc+.5*iTbH);
			var iScr = iTsc+iAdd;
			//trace("s: "+iAdd+" "+iScr);
			//mTbd.scrollTop(iScr); // number is correct, should work but doesn't, scrolls to top: so added delay
			$("<br/>").animate({"foo":1},{"duration":.1,"complete":function(){
				mTbd.scrollTop(iScr);
			}});
		}
		if (bRight) { // show context menu
//			trace(e);
//			e.stopPropagation();
//			e.stopImmediatePropagation();
			mCntx.slideUp("fast",function(){
				mCntx.css({left:e.clientX-3,top:e.clientY-3});//+1
				// check context contents
				// folders
				var oFld = {display:bFolder||bUFolder?"none":"block"};
				mCntx.find("li:has(a.preview)").css(oFld);
				mCntx.find("li:has(a.duplicate)").css(oFld);
				// up folders
				var oFlu = {display:!bUFolder?"block":"none"};
				mCntx.find("li:has(a.rename)").css(oFlu);
				mCntx.find("li:has(a.filedelete)").css(oFlu);
				// check items created by plugins
				$.each( ss.plugins, function(i,sPlugin) {
					//if ($.sfbrowser[sPlugin].checkContextItem) $.sfbrowser[sPlugin].checkContextItem(oFile,mCntx);
					$.sfbrowser[sPlugin].checkContextItem&&$.sfbrowser[sPlugin].checkContextItem(oFile,mCntx);
				});
				mCntx.slideDown("fast");
			});
		} else { // hide context menu
			mCntx.slideUp("fast");
		}
		//
		//if (!ss.keys[16]) trace("todo: shift selection");
		if (!bCTRL) $TbBody.find("tr").each(function(){if (mTr[0]!=$(this)[0]) $(this).removeClass("selected")});
		//
		// check if something is being renamed: if (no other file is being renamed & the table row is selected & file is not an up-folder & shift is not pressed & the first table cell is targeted)
		if (checkRename()[0]!=mTr[0]&&!bRight&&mTr.hasClass("selected")&&!bUFolder&&!ss.keys[17]&&mTr.find("td:eq(0)")[0]==e.target) {
			setTimeout(renameSelected,500,mTr); // rename with timeout to enable doubleclick (input field stops propagation)
		} else {
			if (bCTRL&&!bRight) {
// $$ check # of .selected against selectnum (preferably remove lastly selected)
// but maybe do it on-select, so a multiple select can be used for manipulation (drag,remove)
//				var bOvrSelNum = ss.selectnum!=0&&$TbBody.find("tr.selected").length>=ss.selectnum;
//				if (bOvrSelNum) {
//					trace("remove a selection "+$TbBody.find("tr.selected").length+" of "+ss.selectnum);
//					if (mTr.hasClass("selected")) mTr.toggleClass("selected");
//				} else {
//					mTr.toggleClass("selected");
//				}
				mTr.toggleClass("selected");
			} else {
				mTr.addClass("selected");
			}
		}
		// selection must be in fov
		// table: Chrome, IE, Safari, Opera
		// tbody: FF
		// ss.file causes error for mTr.position() when not used with timout
//		var mTbl = $("#fbtable");
		var iHTbl = $TableH.height();
		var iTrY = mTr.position().top;
		//trace("ehr: "+$TbBody.height()+">"+iHTbl+" || "+$TbBody.get(0).scrollHeight+"!="+iHTbl+"   "+iTrY);
		if ($TbBody.height()>iHTbl||$TbBody.get(0).scrollHeight!=iHTbl) { // body>table
//			trace("jQuery.browser.mozilla: "+jQuery.browser.mozilla);
			var mScroll = jQuery.browser.mozilla?$TbBody:$TableH; // scroll table or body?
			if (iTrY>iHTbl||iTrY<0) {
				var iDff = iTrY>iHTbl?(iTrY-iHTbl):(iTrY-2*mTr.height());
				mScroll.scrollTop(mScroll.scrollTop()+iDff);
				//trace("mScroll.scrollTop "+mScroll.scrollTop()+" -> "+(mScroll.scrollTop()-iDff));
			}
		}
		//
		// preview image
		if ($("#fbpreview").length>0&&$("#fbpreview").attr("class")!=oFile.file) {
			$("#fbpreview").html("");
			var iWprv = $("#fbpreview").width();
			var iHprv = $("#fbpreview").height();
			if (ss.img.indexOf(oFile.mime)!=-1) {// preview Image
				var sFuri = ss.prefx+ss.sfbpath+aPath.join("")+sFile; // $$ todo: cleanup img path
				$("<img src=\""+sFuri+"?"+Math.random()+"\" />").appendTo("#fbpreview").click(function(){$(this).parent().toggleClass("auto")});
			} else if (ss.ascii.indexOf(oFile.mime)!=-1||ss.archive.indexOf(oFile.mime)!=-1) {// preview ascii or zip
				if (oFile.preview) {
					$("#fbpreview").html(oFile.preview);
				} else {
					$("#fbpreview").html(ss.lang.previewText);
					$.ajax({type:"POST", url:ss.conn, data:"a=read&folder="+aPath.join("")+"&file="+sFile, dataType:"json", error:onError, success:function(data, status){
						var sPrv = "";
						if (typeof(data.error)!="undefined") {
							if (data.error!="") {
								trace("sfb error: "+lang(data.error));
								alert(lang(data.error));
							} else if (data.data.type&&data.data.text) {
								trace(lang(data.msg));
								var sMsg = data.data.type=="ascii"?ss.lang.previewPart.replace("#1",ss.previewbytes):ss.lang.previewContents;
								oFile.preview = "<pre><div>"+sMsg+"</div>\n"+data.data.text.replace(/\>/g,"&gt;").replace(/\</g,"&lt;")+"</pre>";
								sPrv = oFile.preview;
							} else {
								trace(lang(data.msg));
							}
						}
						$("#fbpreview").html(sPrv);
					}});
				}
			} else if (oFile.mime=="swf"||oFile.mime=="fla") {// preview flash
				$("#fbpreview").html("<div id=\"previewFlash\"></div>");
				swfobject.embedSWF(
					 ss.sfbpath+aPath.join("")+sFile
					,"previewFlash"
					,iWprv+"px"
					,iHprv+"px"
					,"9.0.0","",{},{menu:"false"}
				);
			} else if (ss.movie.indexOf(oFile.mime)!=-1) {// preview movie
				$("#fbpreview").html("<div id=\"previewMovie\"></div>");
				var sFuri = ss.sfbpath+aPath.join("")+sFile; // $$ todo: cleanup img path
				var sMdPt = oFile.mime=="mp3"?"":"../../"; // $$ todo: extract path from sfbpath
				swfobject.embedSWF(
					 ss.sfbpath+"css/splayer.swf"
					,"previewMovie"
					,iWprv+"px"
					,iHprv+"px"
					,"9.0.0"
					,""
					,{ //flashvars
						 file:		sMdPt+sFuri
						,width:		iWprv
						,height:	iHprv
						,gui:		"playpause,scrubbar"
						,guiOver:	true
						,colors:	'{"bg":"0xFFDEDEDE","bg1":"0xFFBBBBBB","fg":"0xFF666666","fg1":"0xFFD13A3A"}'
					},{ // params
						 menu:	"false"
					}
				);
			}
			$("#fbpreview").attr("class",$("#fbpreview").html()==""?"":oFile.file);
		}

		//
		return false;
	}
	// chooseFile
	function chooseFile(el) {
		trace("chooseFile: "+el); // TRACE ### chooseFile
		var a = 0;
		var aSelected = $TbBody.find("tr.selected");
		var aSelect = [];
		// find selected trs and possible parsed element
		//aSelected.each(function(i,o){Select.push(file(this))});
		aSelected.each(function(i,o){if (i<ss.selectnum||ss.selectnum==0) aSelect.push(file(this))});
		if (el&&el.find) aSelect.push(file(el));
		// check if selection contains directory
		for (var i=0;i<aSelect.length;i++) {
			var oFile = aSelect[i];
			if (oFile.mime=="folder") {
				openDir(oFile.file);
				return false;
			} else if (oFile.mime=="folderup") {
				openDir();
				return false;
			}
		}
		aSelect = unique(aSelect);
		// return clones, not the objects
		for (var i=0;i<aSelect.length;i++) {
			var oFile = aSelect[i];
			var oDupl = new Object();
			for (var p in oFile) oDupl[p] = oFile[p];
			aSelect[i] = oDupl;
		}
		// return
		if (aSelect.length==0) {
			alert(ss.lang.fileNotselected);
		} else {
			if (ss.cookie) setSfbCookie();
			$.each(aSelect,function(i,oFile){oFile.file = sReturnPath+aPath.join("").replace(ss.base,"")+oFile.file;});// todo: correct path
			ss.select(aSelect,ss.selectparams);
			if (bOverlay) closeSFB();
		}
	}
	///////////////////////////////////////////////////////////////////////////////// actions
	//
	// open directory
	function openDir(dir) {
		trace("sfb openDir "+dir+" to "+ss.conn);
		if (dir) dir = String(dir+"/").replace(/(\/+)/gi,"/");
		if (!dir||aPath[aPath.length-1]!=dir) {
			if (dir)	aPath.push(dir);
			else		aPath.pop();
			//
			var oCTree = getPath();
			if (oCTree.filled) { // open cached directory
				fillList(oCTree.contents);
			} else { // open directory with php callback
				$TbBody.html($TrLoading);
				trace("sfb calling fileList");
				$.ajax({type:"POST", url:ss.conn, data:"a=fileList&folder="+aPath.join(""), dataType:"json", error:onError, success:function(data, status){
					trace("sfb callback fileList");
					if (typeof(data.error)!="undefined") {
						if (data.error!="") {
							trace(lang(data.error));
							alert(lang(data.error));
						} else {
							trace(lang(data.msg));
							fillList(data.data);
						}
					}
				}});
			}
			// plugin
			$.each( ss.plugins, function(i,sPlugin) {
				if ($.sfbrowser[sPlugin].openDir) $.sfbrowser[sPlugin].openDir(dir);
			});
		}
	}
	// ajax error callback
	function onError(req, status, err) {	trace("sfb ajax error "+req+" "+status+" "+err); }
	// ajax before send
	//function onBeforeSend(req) {			trace("sfb ajax req "+req); }
	// duplicate file
	function duplicateFile(el) {
		var oFile = file(el);
		var sFile = oFile.file;
		//
		trace("sfb Sending duplication request...");
		$.ajax({type:"POST", url:ss.conn, data:"a=duplicate&folder="+aPath.join("")+"&file="+sFile, dataType:"json", error:onError, success:function(data, status){
			if (typeof(data.error)!="undefined") {
				if (data.error!="") {
					trace(lang(data.error));
					alert(lang(data.error));
				} else {
					trace(lang(data.msg));
					listAdd(data.data,1).trigger('click');
				}
			}
		}});
	}
	// show
	function showFile(e) {
		var mTr = $(e.target).parent().parent();
		var oFile = file(mTr);
		//trace(ss.conn+"?a=download&file="+aPath.join("")+obj.file);
		window.open(ss.conn+"?a=download&file="+aPath.join("")+oFile.file,"_blank");
	}
	// delete
	function deleteFile(e) {
		var mTr = $(e.target).parent().parent();
		var oFile = file(mTr);
		var bFolder = oFile.mime=="folder";
		if (confirm(bFolder?ss.lang.confirmDeletef:ss.lang.confirmDelete)) {
			$.ajax({type:"POST", url:ss.conn, data:"a=delete&folder="+aPath.join("")+"&file="+oFile.file, dataType:"json", error:onError, success:function(data, status){
				if (typeof(data.error)!="undefined") {
					if (data.error!="") {
						trace(lang(data.error));
						alert(lang(data.error));
					} else {
						trace(lang(data.msg));
						$("#fbpreview").html("");
						//
						delete getPath().contents[oFile.file];
						//
						mTr.remove();
					}
				}
			}});
		}
		e.stopPropagation();
	}
	// rename
	function renameSelected(e) {
		var oFile = file(e);
		if (oFile) {
			var mStd = oFile.tr.find("td:eq(0)");
			mStd.html("");
			$("<input type=\"text\" value=\""+oFile.file+"\" />").appendTo(mStd).click(stopEvt).dblclick(stopEvt).mousedown(stopEvt);
		}
	}
	function checkRename() { // $$ first check filename clientside (could save a post)
		var aRenamed = $TbBody.find("tr>td>input");
		if (aRenamed.length>0) {
			var mInput = $(aRenamed[0]);
			var mTd = mInput.parent();
			var mTr = mTd.parent();
			//
			var oFile = file(mTr);
			//
			var sFile = oFile.file;
			var sNFile = mInput.val();
			if (sFile==sNFile) {
				mInput.parent().html(sFile);
			} else {
				$.ajax({type:"POST", url:ss.conn, data:"a=rename&folder="+aPath.join("")+"&file="+sFile+"&nfile="+sNFile, dataType:"json", error:onError, success:function(data, status){
					if (typeof(data.error)!="undefined") {
						if (data.error!="") {
							trace(lang(data.error));
							alert(lang(data.error));
						} else {
							trace(lang(data.msg));
							mTd.html(sNFile);
							oFile.file = sNFile;
						}
					}
				}});
			}
		}
		return mTr?mTr:false;
	}
	// add folder
	function addFolder() {
		trace("sfb addFolder");
		$.ajax({type:"POST", url:ss.conn, data:"a=addFolder&folder="+aPath.join("")+"&foldername="+ss.lang.newfolder, dataType:"json", error:onError, success:function(data, status){
			if (typeof(data.error)!="undefined") {
				if (data.error!="") {
					trace(lang(data.error));
					alert(lang(data.error));
				} else {
					trace(lang(data.msg));
					listAdd(data.data,1).trigger('click').trigger('click');
					sortFbTable(); // todo: fix scrolltop below because because of
					$("#sfbrowser #fbtable").scrollTop(0);	// IE and Safari
					$TbBody.scrollTop(0);		// Firefox
				}
			}
		}});
	}
	// fileUpload
	function fileUpload() {
		var sFile = $SFB.find("#fileToUpload").val();
		trace("sfb fileUpload "+sFile);
		if (sFile=="") return false;
		//
		// check for existing same files
		var sFileName = sFile.split("\\").pop();
		var oExists = getPath().contents[sFileName];
		if (oExists&&!confirm(ss.lang.fileExistsOverwrite)) return false;
		//
		// upload bar
		$("#loadbar").ajaxStart(function(){
			trace("");
			$(this).show();
			loading();
		}).ajaxComplete(function(){
			$(this).hide();
		});
		//
		// ajax upload
		ajaxFileUpload({ // fu
			url:			ss.conn,
			secureuri:		false,
			fileElementId:	"fileToUpload",
			dataType:		"json",
			success: function (data, status) {
				if (typeof(data.error)!="undefined") {
					if (data.error!="") {
						trace("sfb error: "+lang(data.error));
						alert(lang(data.error));
					} else {
						if (oExists) oExists.tr.remove();
						var mTr = listAdd(data.data,1);
						trace("sfb file uploaded: "+data.data.file+" "+mTr[0].nodeName+" "+mTr.attr("id")); 
					}
					return false; // otherwise upload stays open...
				}
			},
			error: function (data, status, e){
				trace(e);
			}
		});
		return false;
	}
	// loading
	function loading() {
		var iPrgMove = Math.ceil((new Date()).getTime()*.3)%512;
		$("#loadbar>div").css("backgroundPosition", "0px "+iPrgMove+"px");
		$("#loadbar:visible").each(function(){setTimeout(loading,20);});
	}
	///////////////////////////////////////////////////////////////////////////////// misc methods
	//
	// get file object from tr
	function file(tr) {
		if (!tr) tr = $TbBody.find("tr.selected:first");
		return getPath().contents[$(tr).attr("id")];
	}
	// find folder in oTree
	function getPath() {
		var oCTree = oTree;
		$.each(aPath,function(i,sPath){
			if (!oCTree[sPath]) oCTree[sPath] = {contents:{},filled:false};
			oCTree = oCTree[sPath];
		});
		return oCTree;
	}
	// addContextItem
	function addContextItem(className,title,fnc,after) {
		var mCItem = $("<li><a class=\"textbutton "+className+"\" title=\""+title+"\"><span>"+title+"</span></a></li>");
		if (after===undefined)	mCItem.appendTo("ul#sfbcontext").find("a").click(fnc).click(function(){$("#sfbcontext").slideUp("fast")});
		else					mCItem.insertAfter("ul#sfbcontext>li:eq("+after+")").find("a").click(fnc).click(function(){$("#sfbcontext").slideUp("fast")});
		return mCItem;
	}
	// lang
	function lang(s) {
		var aStr = s.split("#");
		sReturn = ss.lang[aStr[0]]?ss.lang[aStr[0]]:s;
		if (aStr.length>1) for (var i=1;i<aStr.length;i++) sReturn = sReturn.replace("#"+i,aStr[i]);
		return sReturn;
	}
	// clearObject
	function clearObject(o) {
		for (var sProp in o) delete o[sProp];
	}
	// is numeric
	function isNum(n) {
		return (parseFloat(n)+"")==n;
	}
	// trace
	function trace(o,v) {
		if ((v||ss.debug)&&window.console&&window.console.log) {
			if (typeof(o)=="string")	window.console.log(o);
			else						for (var prop in o) window.console.log(prop+":\t"+String(o[prop]).split("\n")[0]);
		}
	}
	// stop event propagation
	function stopEvt(e) {
		e.stopPropagation();
	}
	////////////////////////////////////////////////////////////////////////////
	// resizing
	//
	// resizeBrowser
	function resizeBrowser() {
		oConstraint.mxw = $Window.width();
		oConstraint.mxh = $Window.height();
		oConstraint.mxx = oConstraint.mxw-$SFBWin.width();
		oConstraint.mxy = oConstraint.mxh-$SFBWin.height();
		if ($SFB.length>0) {
			if (bOverlay) {
				var oPos = $SFBWin.position();
				var iRbX = Math.max(Math.min( oPos.left			,oConstraint.mxx),oConstraint.mnx);
				var iRbY = Math.max(Math.min( oPos.top			,oConstraint.mxy),oConstraint.mny);
				if (iRbX!=oPos.left||iRbY!=oPos.top)				moveWindow(null,iRbX,iRbY);

				var iRbW =Math.max( Math.min( $SFBWin.width()	,oConstraint.mxw),oConstraint.mnw);
				var iRbH =Math.max( Math.min( $SFBWin.height()	,oConstraint.mxh),oConstraint.mnh);
				if (iRbW<$SFBWin.width()||iRbH<$SFBWin.height())	resizeWindow(null,iRbW,iRbH);
			}
		}
	}
	// moveWindow
	function moveWindowDown(e) {
		var iXo = e.pageX-$(e.target).offset().left;
		var iYo = e.pageY-$(e.target).offset().top;
		$("body").mousemove(function(e){
			moveWindow(e,iXo,iYo);
		});
		$("body").mouseup(unbindBody);
	}
	function moveWindow(e,xo,yo) {
		var mPrnO = $("#fbbg").offset();
		var iXps = Math.max(Math.min(	e?e.pageX-xo-mPrnO.left:xo	,oConstraint.mxx),oConstraint.mnx);
		var iYps = Math.max(Math.min(	e?e.pageY-yo-mPrnO.top:yo	,oConstraint.mxy),oConstraint.mny);
		$SFBWin.css({left:iXps+"px",top:iYps+"px"});
	}
	// resizeWindow
	function resizeWindowDown(e) {
		var iXo = e.pageX-$(e.target).offset().left;
		var iYo = e.pageY-$(e.target).offset().top;
		$("body").mousemove(function(e){
			resizeWindow(e,iXo,iYo);
		});
		$("body").mouseup(unbindBody);
	}
	function resizeWindow(e,xo,yo) {
		var oSPos = $SFB.position();
		var oWPos = $SFBWin.position();
		var iWdt = Math.max(Math.min(	e?e.pageX+xo-(oWPos.left+oSPos.left):(xo?xo:$SFBWin.width())	,oConstraint.mxw),oConstraint.mnw);
		var iHgt = Math.max(Math.min(	e?e.pageY+yo-(oWPos.top+oSPos.top):(yo?yo:$SFBWin.height())		,oConstraint.mxh),oConstraint.mnh);
		$SFBWin.css({width:iWdt+"px",height:iHgt+"px"});
		//
		var iPrvH = $SFB.find("#fbpreview").height();
		var iAddH = iPrvH+(iPrvH==null?90:105);
		$TableH.css({height:(iHgt-iAddH+$Table.find("thead").height())+"px"});
		$TbBody.css({height:(iHgt-iAddH)+"px"});
		//
//		var mTblDiv = $("#sfbrowser div#fbtable");
//		var mTable = $("#sfbrowser table");
		if ($Table.width()>$TableH.width()) $Table.find("tr").width($TableH.width());
		$.each( ss.plugins, function(i,sPlugin) {
			if ($.sfbrowser[sPlugin].resizeWindow) $.sfbrowser[sPlugin].resizeWindow(iWdt,iHgt);
		});
	}
	function maximizeSFB(){
		moveWindow(null,0,0);
		resizeWindow(null,$Window.width(),$Window.height());
	}
	function unbindBody(e) {
		$("body").unbind("mousemove");
		$("body").unbind("mouseup");
		if (ss.cookie) setSfbCookie();
	}
	//////////////////////
	//
	// getSfbCookie
	function getSfbCookie() {
		if (ss.cookie) {
			var sCookie = readCookie($.sfbrowser.id);
			trace("sfb get cookie: "+sCookie);
			try {
				oCookie = eval("("+sCookie+")");
				ss.w = Math.min(Math.max(oCookie.w,oConstraint.mnw),oConstraint.mxw);
				ss.h = Math.min(Math.max(oCookie.h,oConstraint.mnh),oConstraint.mxh);
				oConstraint.mxx = $Window.width()  - ss.w;
				oConstraint.mxy = $Window.height() - ss.h;
				ss.x = Math.min(Math.max(oCookie.x,oConstraint.mnx),oConstraint.mxx);
				ss.y = Math.min(Math.max(oCookie.y,oConstraint.mny),oConstraint.mxy);
			} catch (e) {
				trace("sfb cookie error: "+sCookie);
				eraseCookie($.sfbrowser.id);
			}
		} else {
			eraseCookie($.sfbrowser.id);
		}
		return !!oCookie;
	}
	// setSfbCookie
	function setSfbCookie() {
		var mBg = $("#fbbg");
		var oBPos = mBg.position();
		var oPos = $SFBWin.position();
		var sCval = "{"
		sCval += "\"path\":[\""+aPath.toString().replace(/,/g,"\",\"")+"\"]";
		if (bOverlay) {
			sCval += ",\"x\":"+(oPos.left-oBPos.left);
			sCval += ",\"y\":"+(oPos.top-oBPos.top);
			sCval += ",\"w\":"+$SFBWin.width();
			sCval += ",\"h\":"+$SFBWin.height();
		}
		sCval += "}";
		trace("sfb set cookie: "+sCval);
		createCookie($.sfbrowser.id,sCval,356);
	}
	//////////////////////
	//
	// cookie functions
	//
	function createCookie(name,value,days) {
		if (days) {
			var date = new Date();
			date.setTime(date.getTime()+(days*24*60*60*1000));
			var expires = "; expires="+date.toGMTString();
		}
		else var expires = "";
		document.cookie = 	name+"="+value+expires+"; path=/";
	}
	function readCookie(name) {
		var nameEQ = name + "=";
		var ca = document.cookie.split(';');
		for(var i=0;i < ca.length;i++) {
			var c = ca[i];
			while (c.charAt(0)==' ') c = c.substring(1,c.length);
			if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
		}
		return null;
	}
	function eraseCookie(name) {
		createCookie(name,"",-1);
	}

	////////////////////////////////////////////////////////////////
	//
	// here starts copied functions from http://www.phpletter.com/Demo/AjaxFileUpload-Demo/
	// - changed iframe and form creation to jQuery notation
	//
	function ajaxFileUpload(s) {
		trace("sfb ajaxFileUpload");
        // todo: introduce global settings, allowing the client to modify them for all requests, not only timeout		
        s = jQuery.extend({}, jQuery.ajaxSettings, s);
		//
        var iId = new Date().getTime();
		var sFrameId = "jUploadFrame" + iId;
		var sFormId = "jUploadForm" + iId;
		var sFileId = "jUploadFile" + iId;
		//
		// create form
		var mForm = $("<form  action=\"\" method=\"POST\" name=\"" + sFormId + "\" id=\"" + sFormId + "\" enctype=\"multipart/form-data\"><input name=\"a\" type=\"hidden\" value=\"upload\" /><input name=\"folder\" type=\"hidden\" value=\""+aPath.join("")+"\" /><input name=\"allow\" type=\"hidden\" value=\""+ss.allow.join("|")+"\" /><input name=\"deny\" type=\"hidden\" value=\""+ss.deny.join("|")+"\" /><input name=\"resize\" type=\"hidden\" value=\""+ss.resize+"\" /></form>").appendTo('body').css({position:"absolute",top:"-1000px",left:"-1000px"});
		$("#"+s.fileElementId).before($("#"+s.fileElementId).clone(true).val("")).attr('id', s.fileElementId).appendTo(mForm);
		//
		// create iframe
		var mIframe = $("<iframe id=\""+sFrameId+"\" name=\""+sFrameId+"\"  src=\""+(typeof(s.secureuri)=="string"?s.secureuri:"javascript:false")+"\" />").appendTo("body").css({position:"absolute",top:"-1000px",left:"-1000px"});
		var mIframeIO = mIframe[0];
		//
        // Watch for a new set of requests
        if (s.global&&!jQuery.active++) jQuery.event.trigger("ajaxStart");
        var requestDone = false;
        // Create the request object
        var xml = {};
        if (s.global) jQuery.event.trigger("ajaxSend", [xml, s]);
        // Wait for a response to come back
        var uploadCallback = function(isTimeout) {			
			var mIframeIO = document.getElementById(sFrameId);
            try {				
				if(mIframeIO.contentWindow) {
					xml.responseText = mIframeIO.contentWindow.document.body?mIframeIO.contentWindow.document.body.innerHTML:null;
					xml.responseXML = mIframeIO.contentWindow.document.XMLDocument?mIframeIO.contentWindow.document.XMLDocument:mIframeIO.contentWindow.document;
				} else if(mIframeIO.contentDocument) {
					xml.responseText = mIframeIO.contentDocument.document.body?mIframeIO.contentDocument.document.body.innerHTML:null;
                	xml.responseXML = mIframeIO.contentDocument.document.XMLDocument?mIframeIO.contentDocument.document.XMLDocument:mIframeIO.contentDocument.document;
				}						
            } catch(e) {
				jQuery.handleError(s, xml, null, e);
			}
            if (xml||isTimeout=="timeout") {				
                requestDone = true;
                var status;
                try {
                    status = isTimeout != "timeout" ? "success" : "error";
                    // Make sure that the request was successful or notmodified
                    if (status!="error") {
                        // process the data (runs the xml through httpData regardless of callback)
                        var data = uploadHttpData(xml, s.dataType);    
                        // If a local callback was specified, fire it and pass it the data
                        if (s.success) s.success(data, status);
                        // Fire the global callback
                        if (s.global) jQuery.event.trigger("ajaxSuccess", [xml, s]);
                    } else {
                        jQuery.handleError(s, xml, status);
					}
                } catch(e) {
                    status = "error";
                    jQuery.handleError(s, xml, status, e);
                }

                // The request was completed
                if (s.global) jQuery.event.trigger("ajaxComplete", [xml, s]);

                // Handle the global AJAX counter
                if (s.global && ! --jQuery.active) jQuery.event.trigger("ajaxStop");

                // Process result
                if (s.complete) s.complete(xml, status);

				mIframe.unbind();

                setTimeout(function() {
					try {
						mIframe.remove();
						mForm.remove();
					} catch(e) {
						jQuery.handleError(s, xml, null, e);
					}
				}, 100);

                xml = null;
            }
        };
        // Timeout checker // Check to see if the request is still happening
        if (s.timeout>0) setTimeout(function() { if (!requestDone) uploadCallback("timeout"); }, s.timeout);
        
        try {
			mForm.attr("action", s.url).attr("method", "POST").attr("target", sFrameId).attr("encoding", "multipart/form-data").attr("enctype", "multipart/form-data").submit();
        } catch(e) {			
            jQuery.handleError(s, xml, null, e);
        }
		mIframe.load(uploadCallback);
        return {abort: function () {}};
    }
	function uploadHttpData(r, type) {
        var data = !type;
        data = type=="xml" || data?r.responseXML:r.responseText;
		//trace("sfb uploadHttpData: "+data+" "+type+" "+(data?"t":"f"));
		if (data) {
			switch (type) {
				case "script":	jQuery.globalEval(data); break; // If the type is "script", eval it in global context
				case "json":	eval("data = " + data); break; // Get the JavaScript object, if JSON is used.
				case "html":	jQuery("<div>").html(data).evalScripts(); break; // evaluate scripts within html
				default:
			}
		}
        return data;
    }
	// set functions
	$.sfb = $.fn.sfbrowser;
})(jQuery);

// opera jQuery(window).height() bugfix for jQuery 1.2.6
var height_ = jQuery.fn.height;
jQuery.fn.height = function() {
    if ( this[0] == window && jQuery.browser.opera && jQuery.browser.version >= 9.50)
        return window.innerHeight;
    else return height_.apply(this,arguments);
};

// functional equivalents for these prototypes
//Array.prototype.unique=function(){var a=[],i;this.sort();for(i=0;i<this.length;i++){if(this[i]!==this[i+1]){a[a.length]=this[i];}}return a;}
function unique(b) { var a=[],i; b.sort(); for(i=0;i<b.length;i++) if(b[i]!==b[i+1]) a[a.length]=b[i]; return a; }
//if(typeof Array.prototype.copy==='undefined'){Array.prototype.copy=function(a){var a=[],i=this.length;while(i--){a[i]=(typeof this[i].copy!=='undefined')?this[i].copy():this[i];}return a;};}
function copy(b) { var a=[],i = b.length; while (i--) a[i] = b[i].constructor===Array?copy(b[i]):b[i]; return a; }
// $$ fucking IE forces prototype... oh well...
if (!Array.indexOf) Array.prototype.indexOf=function(n){for(var i=0;i<this.length;i++){if(this[i]===n){return i;}}return -1;}


function format_size(size,round) {
	if (!round) round = 0;
    aSize = ['B', 'kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    for (var i=0;size>1024&&aSize.length>i;i++) size /= 1024;
    return Math.round(size,round)+aSize[i];
}
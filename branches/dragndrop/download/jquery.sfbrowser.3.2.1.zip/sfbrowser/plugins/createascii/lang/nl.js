// author: Ron Valstar
jQuery.sfbrowser.addLang({
	 asciiFileNew:			"Nieuw bestand"
	,asciiFileSave:			"Bestand aanpassen"
	,axciiFileNameInvalid:	"Dit is geen geldige bestandsnaam"
	,create:				"Maak"
	,contents:				"Inhoud"
});